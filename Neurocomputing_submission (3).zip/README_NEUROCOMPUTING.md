# Neurocomputing (Elsevier) submission

Class: elsarticle [preprint,12pt], single column, line numbers on.
Build: pdflatex paper_neurocomputing && pdflatex paper_neurocomputing
25 pages including references.

## Zero APC
Neurocomputing is hybrid. Decline the open access option at acceptance and
there is no charge. The APC only applies if you choose OA.

## To change the title
Line with \title{...} near the top. Alternatives considered:
  A (current) Label support overlap determines the efficacy of clustered
              aggregation in federated learning
  B  On the limits of demographic clustering for federated learning under
     severe label skew
  C  When clustered federated learning fails: the role of label support
     overlap in non-IID aggregation
  D  A failure condition for clustered aggregation in federated learning
     under severe non-IID skew
  E  Demographic clustering in federated learning: an empirical study of
     when clustered aggregation helps and when it fails

## Before submitting
1. Highlights file: Elsevier requires 3 to 5 bullet points, max 85 chars each.
2. Declaration of Competing Interest: separate file at submission.
3. CRediT author statement: revise the placeholder in the manuscript.
4. Data availability statement: insert the repository URL.
5. DermaMNIST numbers are transcribed from console output, not computed from
   logs. Regenerate from results_derma/ before submitting.
