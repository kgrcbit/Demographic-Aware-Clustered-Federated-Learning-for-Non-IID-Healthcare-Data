"""
Pure-NumPy MLP backend.

Exists so the tabular (Pima) experiments can be run on a machine without a
working torch install. Implements exactly the 64-32-16 architecture described
in the paper, with SGD + momentum, and supports the client-side variants the
baselines need:

  * plain SGD          -> FedAvg / Edge-Avg / DC-FL / IFCA / CFL / Local-Only
  * proximal term      -> FedProx
  * control variates   -> SCAFFOLD
  * step counting      -> FedNova

Parameters are held as an ordered dict of arrays so the aggregation code in
algorithms_np.py is identical in shape to the torch version.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np


def init_mlp(in_dim: int, hidden: Tuple[int, ...], n_classes: int,
             rng: np.random.Generator) -> "OrderedDict[str, np.ndarray]":
    """He initialisation, matching a standard PyTorch-style MLP."""
    dims = [in_dim, *hidden, n_classes]
    p: "OrderedDict[str, np.ndarray]" = OrderedDict()
    for i in range(len(dims) - 1):
        fan_in = dims[i]
        p[f"W{i}"] = rng.normal(0.0, np.sqrt(2.0 / fan_in), size=(dims[i], dims[i + 1]))
        p[f"b{i}"] = np.zeros(dims[i + 1])
    return p


def n_layers(params) -> int:
    return sum(1 for k in params if k.startswith("W"))


def forward(params, X: np.ndarray):
    """Returns (logits, cache) with ReLU hidden activations."""
    L = n_layers(params)
    a = X
    cache = [X]
    for i in range(L):
        z = a @ params[f"W{i}"] + params[f"b{i}"]
        if i < L - 1:
            a = np.maximum(z, 0.0)
            cache.append(a)
        else:
            a = z
    return a, cache


def softmax_ce(logits: np.ndarray, y: np.ndarray):
    z = logits - logits.max(axis=1, keepdims=True)
    e = np.exp(z)
    p = e / np.maximum(e.sum(axis=1, keepdims=True), 1e-12)
    n = len(y)
    loss = float(-np.log(np.maximum(p[np.arange(n), y], 1e-12)).mean())
    d = p.copy()
    d[np.arange(n), y] -= 1.0
    return loss, d / n


def backward(params, cache, dlogits):
    L = n_layers(params)
    grads: "OrderedDict[str, np.ndarray]" = OrderedDict()
    d = dlogits
    for i in reversed(range(L)):
        a_prev = cache[i]
        grads[f"W{i}"] = a_prev.T @ d
        grads[f"b{i}"] = d.sum(axis=0)
        if i > 0:
            da = d @ params[f"W{i}"].T
            d = da * (cache[i] > 0)
    return OrderedDict((k, grads[k]) for k in params)


@dataclass
class LocalResultNP:
    params: Dict[str, np.ndarray]
    n_samples: int
    steps: int
    train_loss: float
    seconds: float
    c_delta: Dict[str, np.ndarray] | None = None


def local_train(
    global_params,
    X: np.ndarray,
    y: np.ndarray,
    lr: float = 0.01,
    momentum: float = 0.9,
    local_epochs: int = 5,
    batch_size: int = 32,
    prox_mu: float = 0.0,
    use_scaffold: bool = False,
    c_global=None,
    c_local=None,
    grad_clip: float | None = 5.0,
    rng: np.random.Generator | None = None,
) -> LocalResultNP:
    import time
    t0 = time.time()
    rng = rng or np.random.default_rng(0)

    params = OrderedDict((k, v.copy()) for k, v in global_params.items())
    anchor = OrderedDict((k, v.copy()) for k, v in global_params.items())
    vel = OrderedDict((k, np.zeros_like(v)) for k, v in params.items())

    n = len(y)
    total_loss, n_batches, steps = 0.0, 0, 0

    for _ep in range(local_epochs):
        order = rng.permutation(n)
        for s in range(0, n, batch_size):
            idx = order[s:s + batch_size]
            if len(idx) == 0:
                continue
            xb, yb = X[idx], y[idx]
            logits, cache = forward(params, xb)
            loss, dlog = softmax_ce(logits, yb)
            grads = backward(params, cache, dlog)

            if prox_mu > 0.0:  # FedProx
                for k in grads:
                    grads[k] = grads[k] + prox_mu * (params[k] - anchor[k])
                loss += 0.5 * prox_mu * sum(
                    float(((params[k] - anchor[k]) ** 2).sum()) for k in params
                )

            if use_scaffold and c_global is not None and c_local is not None:
                for k in grads:
                    grads[k] = grads[k] + (c_global[k] - c_local[k])

            if grad_clip:
                nrm = np.sqrt(sum(float((g ** 2).sum()) for g in grads.values()))
                if nrm > grad_clip:
                    scale = grad_clip / (nrm + 1e-12)
                    for k in grads:
                        grads[k] *= scale

            for k in params:
                vel[k] = momentum * vel[k] + grads[k]
                params[k] -= lr * vel[k]

            total_loss += loss
            n_batches += 1
            steps += 1

    c_delta = None
    if use_scaffold and c_global is not None and c_local is not None:
        denom = max(1, steps) * lr
        c_delta = OrderedDict(
            (k, -c_global[k] + (anchor[k] - params[k]) / denom) for k in params
        )

    return LocalResultNP(
        params=params, n_samples=n, steps=steps,
        train_loss=total_loss / max(1, n_batches),
        seconds=time.time() - t0, c_delta=c_delta,
    )


def evaluate(params, X: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """Plain accuracy and mean loss. See evaluate_full for imbalance-aware metrics."""
    logits, _ = forward(params, X)
    loss, _ = softmax_ce(logits, y)
    acc = 100.0 * float((logits.argmax(axis=1) == y).mean())
    return acc, loss


def evaluate_full(params, X: np.ndarray, y: np.ndarray, n_classes: int) -> dict:
    """
    Accuracy plus imbalance-aware metrics.

    On a dataset such as DermaMNIST, where one class holds ~67% of the data,
    plain accuracy is uninformative: a constant predictor that always outputs
    the majority class scores ~67% while having learned nothing. Macro-F1 and
    balanced accuracy both go to near zero for such a predictor, so they
    distinguish a real model from a degenerate one.

    Also returns the fraction of predictions falling on the single most
    frequently predicted class ("collapse_frac"). A value near 1.0 is a direct
    indicator that the model has collapsed to a constant output.
    """
    logits, _ = forward(params, X)
    loss, _ = softmax_ce(logits, y)
    pred = logits.argmax(axis=1)

    acc = 100.0 * float((pred == y).mean())

    per_class_recall, f1s = [], []
    for c in range(n_classes):
        tp = float(((pred == c) & (y == c)).sum())
        fp = float(((pred == c) & (y != c)).sum())
        fn = float(((pred != c) & (y == c)).sum())
        support = tp + fn
        if support > 0:
            per_class_recall.append(tp / support)
        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1s.append(2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0.0)

    balanced_acc = 100.0 * float(np.mean(per_class_recall)) if per_class_recall else 0.0
    macro_f1 = 100.0 * float(np.mean(f1s))
    counts = np.bincount(pred, minlength=n_classes)
    collapse_frac = float(counts.max() / max(1, counts.sum()))

    return dict(acc=acc, loss=loss, balanced_acc=balanced_acc,
                macro_f1=macro_f1, collapse_frac=collapse_frac,
                n_predicted_classes=int((counts > 0).sum()))


# ---------------- state arithmetic (mirrors the torch version) -------------
def weighted_sum(param_list: List[dict], weights) -> "OrderedDict[str, np.ndarray]":
    w = np.asarray(weights, dtype=np.float64)
    if w.sum() <= 0:
        raise ValueError("aggregation weights sum to zero")
    w = w / w.sum()
    out = OrderedDict((k, np.zeros_like(v)) for k, v in param_list[0].items())
    for p, wi in zip(param_list, w):
        for k in out:
            out[k] += p[k] * wi
    return out


def sub(a, b):
    return OrderedDict((k, a[k] - b[k]) for k in a)


def add(a, b, scale: float = 1.0):
    return OrderedDict((k, a[k] + scale * b[k]) for k in a)


def flat(p) -> np.ndarray:
    return np.concatenate([v.reshape(-1) for v in p.values()])
