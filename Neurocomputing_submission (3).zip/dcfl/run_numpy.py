"""
Federated simulation runner (NumPy backend, tabular datasets).

Mirrors run.py but uses backend_numpy so it executes without torch.
Writes the same JSONL log format, so analyze.py / figures.py consume the
output unchanged.
"""
from __future__ import annotations

import json
import os
import platform
import time
from collections import OrderedDict
from dataclasses import dataclass, asdict, field
from typing import Dict, List

import numpy as np

from .algorithms import (
    cluster_by_signature,
    cluster_quality_from_losses,
    distribution_signature,
)
from .backend_numpy import (
    add, evaluate, evaluate_full, flat, init_mlp, local_train, sub, weighted_sum,
)
from .partition import partition, partition_report

METHODS = [
    "local_only", "fedavg", "fedprox", "fednova", "scaffold",
    "edge_avg", "ifca", "cfl", "dcfl", "dcfl_vw",
]


@dataclass
class ConfigNP:
    dataset: str = "pima"
    method: str = "dcfl"
    scenario: str = "S2"
    n_clients: int = 5
    rounds: int = 200
    local_epochs: int = 5
    batch_size: int = 32
    lr: float = 0.01
    momentum: float = 0.9
    prox_mu: float = 0.01
    cluster_interval: int = 5
    epsilon: float | None = 1.0
    dp_sensitivity: float | None = None   # None => per-component calibration
    hidden: tuple = (64, 32, 16)
    seed: int = 7
    out_root: str = "results"
    eval_every: int = 5
    target_acc: float = 75.0
    backend: str = "numpy"
    extra: Dict = field(default_factory=dict)


def two_level_aggregate_np(param_list, sizes, labels, quality=None,
                           weighting: str = "clientcount"):
    """
    Stage 1 is always size-weighted averaging within a cluster.

    Stage 2 (the inter-cluster merge) has two variants:

      "clientcount"  beta_m ∝ |G_m| · Q_m       -- as specified in the paper
      "volume"       beta_m ∝ (sum_k∈G_m n_k) · Q_m

    The distinction matters under quantity skew. With client sizes such as
    [10, 278, 29, 175, 122], "clientcount" lets a cluster of two very small
    clients outweigh a cluster holding the single largest client, discarding
    the n_k/N weighting that makes FedAvg consistent. "volume" preserves it
    while still respecting cluster structure.
    """
    clusters = sorted(set(int(c) for c in labels))
    models, weights = [], []
    for c in clusters:
        members = [i for i, l in enumerate(labels) if int(l) == c]
        models.append(weighted_sum([param_list[i] for i in members],
                                   [sizes[i] for i in members]))
        q = 1.0 if quality is None else float(quality.get(c, 1.0))
        mass = (sum(sizes[i] for i in members) if weighting == "volume"
                else len(members))
        weights.append(mass * q)
    return weighted_sum(models, weights), clusters


def cfl_bipartition_np(updates):
    from sklearn.cluster import AgglomerativeClustering
    M = np.vstack([flat(u) for u in updates])
    nrm = np.maximum(np.linalg.norm(M, axis=1, keepdims=True), 1e-12)
    U = M / nrm
    sim = U @ U.T
    dist = np.clip(1.0 - sim, 0.0, 2.0)
    np.fill_diagonal(dist, 0.0)
    if M.shape[0] < 2:
        return np.zeros(M.shape[0], dtype=int), 1.0
    lab = AgglomerativeClustering(n_clusters=2, metric="precomputed",
                                  linkage="complete").fit_predict(dist)
    cross = [sim[i, j] for i in range(len(lab)) for j in range(len(lab)) if lab[i] != lab[j]]
    return lab, (max(cross) if cross else 1.0)


def run_np(cfg: ConfigNP, Xtr, ytr, Xte, yte, parts: List[np.ndarray],
           client_test: List[np.ndarray], n_classes: int):
    out_dir = os.path.join(cfg.out_root, cfg.dataset, cfg.scenario, cfg.method)
    os.makedirs(out_dir, exist_ok=True)
    log_path = os.path.join(out_dir, f"seed{cfg.seed}.jsonl")
    meta_path = os.path.join(out_dir, f"seed{cfg.seed}.meta.json")

    rep = partition_report(ytr, parts)
    with open(meta_path, "w") as f:
        json.dump(dict(config=asdict(cfg), partition_report=rep,
                       numpy=np.__version__, platform=platform.platform(),
                       started=time.strftime("%Y-%m-%dT%H:%M:%S")), f, indent=2)

    rng = np.random.default_rng(cfg.seed)
    in_dim = Xtr.shape[1]
    gp = init_mlp(in_dim, tuple(cfg.hidden), n_classes, np.random.default_rng(cfg.seed))

    c_global = OrderedDict((k, np.zeros_like(v)) for k, v in gp.items())
    c_locals = [OrderedDict((k, np.zeros_like(v)) for k, v in gp.items())
                for _ in range(cfg.n_clients)]
    local_params = [OrderedDict((k, v.copy()) for k, v in gp.items())
                    for _ in range(cfg.n_clients)]
    labels = np.zeros(cfg.n_clients, dtype=int)
    ifca_centers = None
    reached = None

    fout = open(log_path, "w")
    for rnd in range(1, cfg.rounds + 1):
        t0 = time.time()
        results, sizes, steps, losses = [], [], [], []

        for ci in range(cfg.n_clients):
            idx = parts[ci]
            if len(idx) == 0:
                continue
            if cfg.method == "local_only":
                start = local_params[ci]
            elif cfg.method == "ifca" and ifca_centers is not None:
                start = ifca_centers[int(labels[ci])]
            else:
                start = gp
            r = local_train(
                start, Xtr[idx], ytr[idx], lr=cfg.lr, momentum=cfg.momentum,
                local_epochs=cfg.local_epochs, batch_size=cfg.batch_size,
                prox_mu=(cfg.prox_mu if cfg.method == "fedprox" else 0.0),
                use_scaffold=(cfg.method == "scaffold"),
                c_global=c_global if cfg.method == "scaffold" else None,
                c_local=c_locals[ci] if cfg.method == "scaffold" else None,
                rng=np.random.default_rng(cfg.seed * 10007 + rnd * 101 + ci),
            )
            results.append(r); sizes.append(len(idx))
            steps.append(r.steps); losses.append(r.train_loss)
            if cfg.method == "local_only":
                local_params[ci] = r.params
            if cfg.method == "scaffold" and r.c_delta is not None:
                for k in c_locals[ci]:
                    c_locals[ci][k] = c_locals[ci][k] + r.c_delta[k]

        states = [r.params for r in results]
        info: Dict = {}

        if cfg.method == "local_only":
            pass
        elif cfg.method in ("fedavg", "edge_avg", "fedprox"):
            gp = weighted_sum(states, sizes)
        elif cfg.method == "fednova":
            w = np.asarray(sizes, float); w /= w.sum()
            taus = np.asarray(steps, float); tau_eff = float((w * taus).sum())
            norm = [OrderedDict((k, (s[k] - gp[k]) / max(t, 1.0)) for k in gp)
                    for s, t in zip(states, taus)]
            agg = weighted_sum(norm, w)
            gp = OrderedDict((k, gp[k] + tau_eff * agg[k]) for k in gp)
        elif cfg.method == "scaffold":
            avg = weighted_sum(states, sizes)
            gp = add(gp, sub(avg, gp), 1.0)
            ds = [r.c_delta for r in results if r.c_delta is not None]
            if ds:
                for k in c_global:
                    c_global[k] = c_global[k] + sum(d[k] for d in ds) / cfg.n_clients
        elif cfg.method == "cfl":
            labels, cross = cfl_bipartition_np([sub(s, gp) for s in states])
            info["cfl_max_cross_similarity"] = float(cross)
            gp, cl = two_level_aggregate_np(states, sizes, labels, None)
            info["clusters"] = [int(c) for c in cl]
        elif cfg.method == "ifca":
            if ifca_centers is None:
                m = max(2, min(3, cfg.n_clients - 1))
                ifca_centers = [
                    OrderedDict((k, v + 0.01 * np.random.default_rng(cfg.seed + j).normal(size=v.shape))
                                for k, v in gp.items())
                    for j in range(m)
                ]
            for c in range(len(ifca_centers)):
                mem = [i for i in range(len(states)) if int(labels[i]) == c]
                if mem:
                    ifca_centers[c] = weighted_sum([states[i] for i in mem],
                                                   [sizes[i] for i in mem])
            newlab = np.zeros(len(states), dtype=int)
            for i in range(len(states)):
                ls = [evaluate(ct, Xtr[parts[i]], ytr[parts[i]])[1] for ct in ifca_centers]
                newlab[i] = int(np.argmin(ls))
            labels = newlab
            info["ifca_assignment"] = labels.tolist()
            gp = weighted_sum(ifca_centers,
                              [max(1, int((labels == c).sum())) for c in range(len(ifca_centers))])
        elif cfg.method in ("dcfl", "dcfl_vw"):
            if (rnd - 1) % cfg.cluster_interval == 0:
                sigs = []
                for ci in range(cfg.n_clients):
                    idx = parts[ci]
                    fm = Xtr[idx].mean(axis=0); fs = Xtr[idx].std(axis=0)
                    sigs.append(distribution_signature(
                        ytr[idx], fm, fs, n_classes,
                        epsilon=cfg.epsilon, sensitivity=cfg.dp_sensitivity,
                        rng=np.random.default_rng(cfg.seed * 991 + rnd * 13 + ci)))
                labels = cluster_by_signature(np.vstack(sigs))
                info["reclustered"] = True
                info["cluster_labels"] = labels.tolist()
            q = cluster_quality_from_losses(labels, losses)
            gp, cl = two_level_aggregate_np(
                states, sizes, labels, q,
                weighting=("volume" if cfg.method == "dcfl_vw" else "clientcount"))
            info["clusters"] = [int(c) for c in cl]
        else:
            raise AssertionError(cfg.method)

        rec = dict(round=rnd, method=cfg.method, scenario=cfg.scenario,
                   seed=cfg.seed, dataset=cfg.dataset,
                   train_loss=float(np.mean(losses)),
                   round_seconds=float(time.time() - t0),
                   client_sizes=[int(s) for s in sizes], **info)

        if rnd % cfg.eval_every == 0 or rnd == cfg.rounds:
            if cfg.method == "local_only":
                fulls = [evaluate_full(local_params[i], Xte, yte, n_classes)
                         for i in range(cfg.n_clients)]
                rec["global_acc"] = float(np.mean([f["acc"] for f in fulls]))
                rec["balanced_acc"] = float(np.mean([f["balanced_acc"] for f in fulls]))
                rec["macro_f1"] = float(np.mean([f["macro_f1"] for f in fulls]))
                rec["collapse_frac"] = float(np.mean([f["collapse_frac"] for f in fulls]))
            else:
                f = evaluate_full(gp, Xte, yte, n_classes)
                rec["global_acc"] = float(f["acc"])
                rec["balanced_acc"] = float(f["balanced_acc"])
                rec["macro_f1"] = float(f["macro_f1"])
                rec["collapse_frac"] = float(f["collapse_frac"])
                rec["n_predicted_classes"] = int(f["n_predicted_classes"])
            per = []
            for ci, tidx in enumerate(client_test):
                if len(tidx) == 0:
                    continue
                st = local_params[ci] if cfg.method == "local_only" else gp
                per.append(float(evaluate(st, Xte[tidx], yte[tidx])[0]))
            if per:
                rec["per_client_acc"] = per
                rec["fairness_sigma"] = float(np.std(per))
            if reached is None and rec["global_acc"] >= cfg.target_acc:
                reached = rnd
            rec["reached_target_round"] = reached

        fout.write(json.dumps(rec) + "\n")
    fout.close()

    with open(meta_path) as f:
        meta = json.load(f)
    meta["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    meta["reached_target_round"] = reached
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    return log_path
