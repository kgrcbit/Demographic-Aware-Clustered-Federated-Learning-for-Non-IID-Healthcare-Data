"""
Models, local training loops, and evaluation.

Local trainers implement the client-side variants the baselines require:
  * plain SGD           -> FedAvg / Edge-Avg / DC-FL / IFCA / CFL
  * proximal term       -> FedProx
  * control variates    -> SCAFFOLD
  * step counting       -> FedNova
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader


# --------------------------------------------------------------------------
# models
# --------------------------------------------------------------------------
def build_model(name: str, n_classes: int, in_dim: int | None = None) -> nn.Module:
    """
    name in {"resnet18", "densenet121", "mlp"}.
    Image backbones use torchvision; `mlp` is the tabular model (Pima).
    """
    name = name.lower()
    if name == "mlp":
        if in_dim is None:
            raise ValueError("mlp requires in_dim")
        return nn.Sequential(
            nn.Linear(in_dim, 64), nn.ReLU(),
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 16), nn.ReLU(),
            nn.Linear(16, n_classes),
        )

    import torchvision.models as tvm

    if name == "resnet18":
        m = tvm.resnet18(weights=tvm.ResNet18_Weights.IMAGENET1K_V1)
        m.fc = nn.Linear(m.fc.in_features, n_classes)
        return m
    if name == "densenet121":
        m = tvm.densenet121(weights=tvm.DenseNet121_Weights.IMAGENET1K_V1)
        m.classifier = nn.Linear(m.classifier.in_features, n_classes)
        return m
    raise KeyError(f"unknown model {name!r}")


# --------------------------------------------------------------------------
# local training
# --------------------------------------------------------------------------
@dataclass
class LocalResult:
    state: Dict[str, torch.Tensor]
    n_samples: int
    steps: int
    train_loss: float
    seconds: float
    c_delta: Dict[str, torch.Tensor] | None = None  # SCAFFOLD


class LocalTrainer:
    def __init__(
        self,
        model: nn.Module,
        device: str = "cpu",
        lr: float = 0.01,
        momentum: float = 0.9,
        local_epochs: int = 5,
        prox_mu: float = 0.0,          # FedProx
        use_scaffold: bool = False,    # SCAFFOLD
        grad_clip: float | None = 5.0,
    ):
        self.model = model
        self.device = device
        self.lr = lr
        self.momentum = momentum
        self.local_epochs = local_epochs
        self.prox_mu = prox_mu
        self.use_scaffold = use_scaffold
        self.grad_clip = grad_clip

    def train(
        self,
        global_state: Dict[str, torch.Tensor],
        loader: DataLoader,
        c_global: Dict[str, torch.Tensor] | None = None,
        c_local: Dict[str, torch.Tensor] | None = None,
    ) -> LocalResult:
        import time

        t0 = time.time()
        self.model.load_state_dict(global_state)
        self.model.to(self.device).train()
        opt = torch.optim.SGD(self.model.parameters(), lr=self.lr, momentum=self.momentum)

        global_params = {k: v.detach().clone().to(self.device) for k, v in global_state.items()}
        total_loss, n_batches, steps, n_seen = 0.0, 0, 0, 0

        for _ep in range(self.local_epochs):
            for xb, yb in loader:
                xb, yb = xb.to(self.device), yb.to(self.device)
                opt.zero_grad(set_to_none=True)
                out = self.model(xb)
                loss = F.cross_entropy(out, yb)

                if self.prox_mu > 0:  # FedProx proximal term
                    prox = 0.0
                    for name, p in self.model.named_parameters():
                        prox = prox + ((p - global_params[name]) ** 2).sum()
                    loss = loss + 0.5 * self.prox_mu * prox

                loss.backward()
                if self.grad_clip:
                    nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)

                if self.use_scaffold and c_global is not None and c_local is not None:
                    # SCAFFOLD correction: g <- g - c_i + c
                    with torch.no_grad():
                        for name, p in self.model.named_parameters():
                            if p.grad is None:
                                continue
                            p.grad += (c_global[name].to(self.device) - c_local[name].to(self.device))

                opt.step()
                total_loss += float(loss.detach().cpu())
                n_batches += 1
                steps += 1
                n_seen += int(yb.numel())

        new_state = OrderedDict(
            (k, v.detach().cpu().clone()) for k, v in self.model.state_dict().items()
        )

        c_delta = None
        if self.use_scaffold and c_global is not None and c_local is not None:
            # c_i^+ = c_i - c + (x - y_i) / (K * lr)
            c_delta = OrderedDict()
            denom = max(1, steps) * self.lr
            for k in global_state:
                if not torch.is_floating_point(global_state[k]):
                    c_delta[k] = torch.zeros_like(global_state[k], dtype=torch.float32)
                    continue
                c_delta[k] = (
                    -c_global[k].cpu()
                    + (global_state[k].cpu().float() - new_state[k].float()) / denom
                )

        return LocalResult(
            state=new_state,
            n_samples=n_seen // max(1, self.local_epochs),
            steps=steps,
            train_loss=total_loss / max(1, n_batches),
            seconds=time.time() - t0,
            c_delta=c_delta,
        )


@torch.no_grad()
def evaluate(model: nn.Module, state: Dict[str, torch.Tensor], loader: DataLoader,
             device: str = "cpu") -> Tuple[float, float]:
    """Returns (accuracy_percent, mean_loss). Real forward passes only."""
    model.load_state_dict(state)
    model.to(device).eval()
    correct, total, loss_sum, n_batches = 0, 0, 0.0, 0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        out = model(xb)
        loss_sum += float(F.cross_entropy(out, yb).cpu())
        n_batches += 1
        correct += int((out.argmax(1) == yb).sum().cpu())
        total += int(yb.numel())
    acc = 100.0 * correct / max(1, total)
    return acc, loss_sum / max(1, n_batches)


def feature_stats_for_signature(loader: DataLoader, max_batches: int = 20) -> tuple:
    """
    Cheap per-client feature summary used by the DC-FL signature: channel-wise
    mean/std for images, column mean/std for tabular. Computed from real data.
    """
    means, stds, seen = [], [], 0
    for xb, _ in loader:
        x = xb.float()
        if x.dim() == 4:      # N,C,H,W -> per-channel
            means.append(x.mean(dim=(0, 2, 3)).cpu().numpy())
            stds.append(x.std(dim=(0, 2, 3)).cpu().numpy())
        else:                 # N,D -> per-column
            means.append(x.mean(dim=0).cpu().numpy())
            stds.append(x.std(dim=0).cpu().numpy())
        seen += 1
        if seen >= max_batches:
            break
    if not means:
        return None, None
    return np.mean(means, axis=0), np.mean(stds, axis=0)
