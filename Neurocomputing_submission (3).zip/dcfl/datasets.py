"""
Dataset loading.

Each loader returns (train_ds, test_ds, train_labels, n_classes, in_dim).
Image datasets expect the standard on-disk layouts described in README.md;
nothing is downloaded silently and nothing is synthesised.

`make_client_test_indices` builds per-client test shards that mirror each
client's TRAIN label distribution. This matters: per-hospital accuracy (and
therefore the fairness index sigma_A) is only meaningful if each hospital is
evaluated on a test set resembling its own patient population.
"""
from __future__ import annotations

import os
from typing import List, Tuple

import numpy as np

try:
    import torch
    from torch.utils.data import Dataset
    _HAS_TORCH = True
except Exception:  # analysis / numpy-backend use does not need torch
    _HAS_TORCH = False
    class Dataset:  # minimal stand-in so the module imports
        pass


class TabularDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        return self.X[i], self.y[i]


def load_pima(csv_path: str, test_frac: float = 0.2, seed: int = 0):
    """
    Pima Indians Diabetes: 768 rows, 8 features, binary label in last column.
    Standardized using TRAIN statistics only (no leakage).
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(
            f"Pima CSV not found at {csv_path}. Download 'diabetes.csv' "
            f"(768 rows, 9 columns) and pass --data-path."
        )
    raw = np.genfromtxt(csv_path, delimiter=",", skip_header=1)
    if raw.ndim != 2 or raw.shape[1] != 9:
        raise ValueError(f"expected 9 columns in {csv_path}, got shape {raw.shape}")
    X, y = raw[:, :8].astype(np.float64), raw[:, 8].astype(int)

    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(y))
    n_test = int(round(test_frac * len(y)))
    te, tr = idx[:n_test], idx[n_test:]

    mu, sd = X[tr].mean(0), X[tr].std(0)
    sd[sd == 0] = 1.0
    Xs = (X - mu) / sd

    return (TabularDataset(Xs[tr], y[tr]), TabularDataset(Xs[te], y[te]),
            y[tr], 2, 8)


def load_image_folder(root: str, image_size: int = 224, test_frac: float = 0.2,
                      seed: int = 0):
    """
    Generic ImageFolder loader (used for ISIC 2019 and ChestX-ray14 once the
    images are arranged as root/<class_name>/*.jpg).
    """
    from torchvision import datasets, transforms

    if not os.path.isdir(root):
        raise FileNotFoundError(
            f"image root {root} not found. Arrange the dataset as "
            f"{root}/<class_name>/*.jpg and pass --data-path."
        )
    tf_train = transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])
    tf_test = transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])
    full_train = datasets.ImageFolder(root, transform=tf_train)
    full_test = datasets.ImageFolder(root, transform=tf_test)
    labels = np.array([s[1] for s in full_train.samples])

    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(labels))
    n_test = int(round(test_frac * len(labels)))
    te, tr = idx[:n_test], idx[n_test:]

    from torch.utils.data import Subset
    return (Subset(full_train, tr.tolist()), Subset(full_test, te.tolist()),
            labels[tr], len(full_train.classes), None)


def make_client_test_indices(test_labels: np.ndarray,
                             client_train_parts: List[np.ndarray],
                             train_labels: np.ndarray,
                             seed: int = 0) -> List[np.ndarray]:
    """
    Build per-client test shards whose label mix matches each client's train mix.
    Sampling is WITH replacement only if a class is exhausted, and each shard is
    capped so shards stay comparable in size.
    """
    rng = np.random.default_rng(seed)
    n_classes = int(max(train_labels.max(), test_labels.max())) + 1
    by_class = {c: np.where(test_labels == c)[0] for c in range(n_classes)}
    shard_size = max(50, len(test_labels) // max(1, len(client_train_parts)))

    shards = []
    for part in client_train_parts:
        y = train_labels[part]
        props = np.bincount(y, minlength=n_classes) / max(1, len(y))
        picks = []
        for c in range(n_classes):
            k = int(round(props[c] * shard_size))
            pool = by_class[c]
            if k <= 0 or len(pool) == 0:
                continue
            picks.append(rng.choice(pool, size=min(k, len(pool)), replace=False))
        shards.append(np.array(sorted(np.concatenate(picks))) if picks
                      else np.array([], dtype=int))
    return shards
