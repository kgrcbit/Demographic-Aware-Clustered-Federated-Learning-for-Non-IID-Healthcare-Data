"""
Non-IID partitioning for federated healthcare simulation.

Implements the IID / S1 / S2 / S3 / S4 scenarios described in the paper,
using Dirichlet-based label partitioning (Hsu et al., 2019) plus optional
quantity skew and feature noise.

Every partition is fully determined by (scenario, n_clients, seed) so that
runs are exactly reproducible and the per-seed partition can be re-derived
and audited later.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from typing import Dict, List

import numpy as np


SCENARIOS = {
    #                alpha   size_var  feature_noise
    "IID": dict(alpha=None, size_var=1.0, feature_noise=0.0),
    "S1":  dict(alpha=1.0,  size_var=1.0, feature_noise=0.0),
    "S2":  dict(alpha=0.1,  size_var=1.0, feature_noise=0.0),
    "S3":  dict(alpha=0.5,  size_var=10.0, feature_noise=0.0),
    "S4":  dict(alpha=0.1,  size_var=10.0, feature_noise=0.05),
}


@dataclass
class PartitionSpec:
    scenario: str
    n_clients: int
    seed: int
    alpha: float | None
    size_var: float
    feature_noise: float

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)


def _dirichlet_label_partition(
    labels: np.ndarray,
    n_clients: int,
    alpha: float,
    rng: np.random.Generator,
    min_per_client: int = 10,
) -> List[np.ndarray]:
    """
    Classic Dirichlet label-skew partition. For each class c, draw
    p_c ~ Dir(alpha * 1_K) and split that class's indices across clients
    according to p_c. Retries until every client has >= min_per_client.
    """
    n_classes = int(labels.max()) + 1
    for _attempt in range(100):
        idx_per_client: List[List[int]] = [[] for _ in range(n_clients)]
        for c in range(n_classes):
            idx_c = np.where(labels == c)[0]
            rng.shuffle(idx_c)
            props = rng.dirichlet(np.repeat(alpha, n_clients))
            cuts = (np.cumsum(props) * len(idx_c)).astype(int)[:-1]
            for k, part in enumerate(np.split(idx_c, cuts)):
                idx_per_client[k].extend(part.tolist())
        sizes = [len(v) for v in idx_per_client]
        if min(sizes) >= min_per_client:
            return [np.array(sorted(v)) for v in idx_per_client]
    raise RuntimeError(
        f"Could not build a Dirichlet partition with >= {min_per_client} "
        f"samples per client after 100 attempts (alpha={alpha}, K={n_clients}). "
        f"Lower min_per_client or raise alpha."
    )


def _iid_partition(n_samples: int, n_clients: int, rng: np.random.Generator) -> List[np.ndarray]:
    idx = np.arange(n_samples)
    rng.shuffle(idx)
    return [np.array(sorted(p)) for p in np.array_split(idx, n_clients)]


def _apply_quantity_skew(
    parts: List[np.ndarray],
    size_var: float,
    rng: np.random.Generator,
    min_per_client: int = 10,
) -> List[np.ndarray]:
    """
    Subsample clients so that the ACHIEVED |largest| / |smallest| ratio
    matches size_var as closely as the available data allows.

    We target absolute sizes on a geometric ladder rather than scaling each
    client's existing size, because the Dirichlet step already introduces
    size variance; multiplying ratios into it would give an uncontrolled
    (and typically much smaller) achieved ratio than requested.

    The ladder is capped by each client's available samples, so the achieved
    ratio is always re-measured by partition_report() rather than assumed.
    """
    if size_var <= 1.0:
        return parts
    k = len(parts)
    avail = np.array([len(p) for p in parts], dtype=float)

    # Assign the largest rung to the client that actually has the most data.
    # Assigning rungs at random lets a small client land on a high rung, which
    # collapses the feasible anchor and discards most of the dataset -- severe
    # on small datasets such as Pima.
    order = np.argsort(-avail)  # client indices, largest available first
    # Geometric ladder of TARGET sizes, largest rung anchored so that the
    # ladder is feasible given what each assigned client actually has.
    rungs = np.geomspace(1.0, 1.0 / size_var, num=k)  # relative target sizes

    # Largest feasible anchor: for each rung/client pair, anchor <= avail/rung
    anchor = np.min(avail[order] / rungs)
    targets = np.maximum(min_per_client, np.floor(anchor * rungs)).astype(int)

    out: List[np.ndarray] = [None] * k  # type: ignore
    for slot, client in enumerate(order):
        p = parts[client]
        keep = int(min(targets[slot], len(p)))
        keep = max(keep, min(min_per_client, len(p)))
        sel = rng.choice(p, size=keep, replace=False)
        out[client] = np.array(sorted(sel))
    return out


def partition(
    labels: np.ndarray,
    scenario: str,
    n_clients: int,
    seed: int,
    min_per_client: int = 10,
) -> tuple[List[np.ndarray], PartitionSpec]:
    """
    Build a client partition for the given scenario.

    Returns (list_of_index_arrays, spec). Deterministic given seed.
    """
    if scenario not in SCENARIOS:
        raise KeyError(f"Unknown scenario {scenario!r}; expected one of {sorted(SCENARIOS)}")
    cfg = SCENARIOS[scenario]
    rng = np.random.default_rng(seed)

    if cfg["alpha"] is None:
        parts = _iid_partition(len(labels), n_clients, rng)
    else:
        parts = _dirichlet_label_partition(
            labels, n_clients, cfg["alpha"], rng, min_per_client=min_per_client
        )

    parts = _apply_quantity_skew(parts, cfg["size_var"], rng, min_per_client=min_per_client)

    spec = PartitionSpec(
        scenario=scenario,
        n_clients=n_clients,
        seed=seed,
        alpha=cfg["alpha"],
        size_var=cfg["size_var"],
        feature_noise=cfg["feature_noise"],
    )
    return parts, spec


def partition_report(labels: np.ndarray, parts: List[np.ndarray]) -> Dict:
    """
    Summarize a partition: per-client size and class distribution.
    Use this to populate the data-volume table in the paper with REAL numbers.
    """
    n_classes = int(labels.max()) + 1
    rows = []
    for k, idx in enumerate(parts):
        y = labels[idx]
        counts = np.bincount(y, minlength=n_classes)
        props = counts / max(1, counts.sum())
        dom = int(np.argmax(counts))
        rows.append(
            dict(
                client=k,
                n=int(len(idx)),
                dominant_class=dom,
                dominant_frac=float(props[dom]),
                class_counts=counts.tolist(),
            )
        )
    sizes = np.array([r["n"] for r in rows], dtype=float)
    return dict(
        clients=rows,
        total=int(sizes.sum()),
        size_ratio=float(sizes.max() / max(1.0, sizes.min())),
    )
