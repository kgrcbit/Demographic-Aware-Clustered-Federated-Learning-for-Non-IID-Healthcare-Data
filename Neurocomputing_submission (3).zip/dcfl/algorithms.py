"""
Federated aggregation strategies.

Includes DC-FL (this work) and the baselines it is compared against:
  Local-Only, FedAvg, FedProx, FedNova, SCAFFOLD, Edge-Avg,
  plus the two clustered-FL competitors the reviewer will expect:
  IFCA (Ghosh et al. 2020) and CFL (Sattler et al. 2021).

Design notes
------------
* Model state is handled as an OrderedDict[str, Tensor] ("state dict").
  All aggregation is expressed over these dicts so the same code works for
  ResNet-18, DenseNet-121 and the tabular MLP without modification.
* Local training is supplied by the caller (see engine.LocalTrainer), so the
  aggregation logic here stays framework-light and unit-testable.
* Nothing here fabricates a metric. Every number an algorithm reports comes
  from an actual local evaluation pass.
"""
from __future__ import annotations

from collections import OrderedDict
from typing import Dict, List, Sequence, Tuple

import numpy as np

try:  # torch is required to run, but the module should be importable without it
    import torch
    _HAS_TORCH = True
except Exception:  # pragma: no cover
    torch = None  # type: ignore
    _HAS_TORCH = False


# --------------------------------------------------------------------------
# state-dict arithmetic helpers
# --------------------------------------------------------------------------
def sd_zeros_like(sd):
    return OrderedDict((k, torch.zeros_like(v, dtype=torch.float32)) for k, v in sd.items())


def sd_weighted_sum(sds: Sequence[dict], weights: Sequence[float]):
    """sum_i w_i * sd_i  (weights need not be normalized; they are normalized here)."""
    if len(sds) == 0:
        raise ValueError("no state dicts to aggregate")
    w = np.asarray(weights, dtype=np.float64)
    if w.sum() <= 0:
        raise ValueError("aggregation weights sum to zero")
    w = w / w.sum()
    out = sd_zeros_like(sds[0])
    for sd, wi in zip(sds, w):
        for k in out:
            out[k] += sd[k].to(torch.float32) * float(wi)
    return out


def sd_sub(a, b):
    return OrderedDict((k, a[k].to(torch.float32) - b[k].to(torch.float32)) for k in a)


def sd_add(a, b, scale: float = 1.0):
    return OrderedDict((k, a[k].to(torch.float32) + scale * b[k].to(torch.float32)) for k in a)


def sd_flat(sd) -> "torch.Tensor":
    return torch.cat([v.reshape(-1).to(torch.float32) for v in sd.values()])


# --------------------------------------------------------------------------
# DC-FL components
# --------------------------------------------------------------------------
def distribution_signature(
    labels: np.ndarray,
    features_mean: np.ndarray | None,
    features_std: np.ndarray | None,
    n_classes: int,
    epsilon: float | None = 1.0,
    sensitivity: float | None = None,
    feature_range: float = 1.0,
    rng: np.random.Generator | None = None,
) -> np.ndarray:
    """
    Build s_k = [class proportions ; feature means ; feature stds], optionally
    perturbed with Laplacian noise for (epsilon)-differential privacy.

    Sensitivity
    -----------
    The signature has heterogeneous components, so a single scalar sensitivity
    is wrong. We calibrate per block:

    * class proportions: changing one patient record moves two histogram
      counts by 1, so the L1 sensitivity of the PROPORTION vector is 2/n.
    * feature means over n records with values bounded in a range R:
      sensitivity R/n.
    * feature stds: bounded above by R/sqrt(n); we use R/n as a practical
      (conservative-in-noise, cheap) proxy.

    Passing an explicit `sensitivity` overrides this and applies one scale to
    every component -- do not do that unless you know why. Using
    sensitivity=1.0 with proportions in [0,1] injects noise of the same
    magnitude as the signal and destroys the clustering signal entirely at
    epsilon<=1 (empirically: cluster recovery drops to chance).

    epsilon=None disables the noise (used for the privacy-ablation study).
    """
    n = max(1, int(len(labels)))
    counts = np.bincount(labels, minlength=n_classes).astype(np.float64)
    props = counts / max(1.0, counts.sum())

    parts = [props]
    scales = [np.full(n_classes, 2.0 / n)]

    if features_mean is not None:
        fm = np.asarray(features_mean, dtype=np.float64).reshape(-1)
        parts.append(fm)
        scales.append(np.full(fm.shape, feature_range / n))
    if features_std is not None:
        fs = np.asarray(features_std, dtype=np.float64).reshape(-1)
        parts.append(fs)
        scales.append(np.full(fs.shape, feature_range / n))

    s = np.concatenate(parts)
    sens = np.concatenate(scales) if sensitivity is None else np.full(s.shape, float(sensitivity))

    if epsilon is not None and epsilon > 0:
        rng = rng or np.random.default_rng()
        s = s + rng.laplace(loc=0.0, scale=sens / epsilon, size=s.shape)
    return s


def cosine_similarity_matrix(sigs: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(sigs, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    unit = sigs / norms
    return unit @ unit.T


def cluster_by_signature(
    sigs: np.ndarray,
    min_clusters: int = 2,
    max_clusters: int | None = None,
    min_cluster_size: int = 1,
) -> np.ndarray:
    """
    Hierarchical agglomerative clustering on cosine distance, with the number
    of clusters chosen by maximizing silhouette score (as described in the
    paper). Returns an integer label per client.

    Falls back to a single cluster when K is too small to silhouette-score.
    """
    from sklearn.cluster import AgglomerativeClustering
    from sklearn.metrics import silhouette_score

    k_clients = sigs.shape[0]
    if k_clients < 3:
        return np.zeros(k_clients, dtype=int)

    norms = np.maximum(np.linalg.norm(sigs, axis=1, keepdims=True), 1e-12)
    unit = sigs / norms
    dist = np.clip(1.0 - (unit @ unit.T), 0.0, 2.0)
    np.fill_diagonal(dist, 0.0)

    hi = max_clusters or max(min_clusters, min(k_clients - 1, k_clients // 2 + 1))
    hi = min(hi, k_clients - 1)
    best_labels = np.zeros(k_clients, dtype=int)
    best_score = -np.inf

    for m in range(min_clusters, hi + 1):
        model = AgglomerativeClustering(n_clusters=m, metric="precomputed", linkage="average")
        lab = model.fit_predict(dist)
        # enforce a minimum cluster size if requested
        if min_cluster_size > 1:
            sizes = np.bincount(lab, minlength=m)
            if sizes.min() < min_cluster_size:
                continue
        try:
            score = silhouette_score(dist, lab, metric="precomputed")
        except Exception:
            continue
        if score > best_score:
            best_score, best_labels = score, lab
    return best_labels


def two_level_aggregate(
    client_states: List[dict],
    client_sizes: Sequence[int],
    cluster_labels: np.ndarray,
    cluster_quality: Dict[int, float] | None = None,
):
    """
    Stage 1: size-weighted average within each cluster.
    Stage 2: merge cluster models with weights beta_m ∝ |G_m| * Q_m,
             where Q_m is a cluster quality score (inverse within-cluster
             loss variance, supplied by the caller from REAL local losses).
    """
    clusters = sorted(set(int(c) for c in cluster_labels))
    cluster_models, cluster_weights = [], []
    for c in clusters:
        members = [i for i, lab in enumerate(cluster_labels) if int(lab) == c]
        sds = [client_states[i] for i in members]
        ws = [client_sizes[i] for i in members]
        cluster_models.append(sd_weighted_sum(sds, ws))
        q = 1.0 if cluster_quality is None else float(cluster_quality.get(c, 1.0))
        cluster_weights.append(len(members) * q)
    return sd_weighted_sum(cluster_models, cluster_weights), clusters


def cluster_quality_from_losses(
    cluster_labels: np.ndarray,
    client_losses: Sequence[float],
    eps: float = 1e-6,
    q_max: float | None = None,
    singleton_policy: str = "median",
) -> Dict[int, float]:
    """
    Q_m = 1 / (variance of local losses within cluster m), from real losses.

    Two degenerate cases must be handled explicitly, or the inter-cluster
    merge collapses onto a single client:

    1. A SINGLETON cluster has zero within-cluster variance by definition, so
       the naive formula gives Q = 1/eps = 1e6 and that one client's model
       receives essentially all of the merge weight. Empirically this is
       catastrophic under severe label skew, where singleton clusters are
       common: the global model becomes one hospital's local model and
       accuracy falls below FedAvg. We therefore do not let a singleton's
       quality be inferred from a variance it cannot have. The default
       ("median") assigns it the median quality of the non-singleton
       clusters; "neutral" assigns 1.0.
    2. A cluster whose members happen to have near-identical losses produces
       an unboundedly large Q for the same reason. q_max caps this; by
       default it is set to the largest finite non-degenerate Q observed.
    """
    q: Dict[int, float] = {}
    singletons: List[int] = []
    for c in sorted(set(int(x) for x in cluster_labels)):
        vals = [client_losses[i] for i, lab in enumerate(cluster_labels) if int(lab) == c]
        if len(vals) < 2:
            singletons.append(c)
            continue
        q[c] = 1.0 / (float(np.var(vals)) + eps)

    if q:
        cap = q_max if q_max is not None else float(np.max(list(q.values())))
        q = {k: min(v, cap) for k, v in q.items()}
        fill = float(np.median(list(q.values()))) if singleton_policy == "median" else 1.0
    else:
        fill = 1.0  # every cluster is a singleton -> fall back to equal weight

    for c in singletons:
        q[c] = fill
    return dict(sorted(q.items()))


# --------------------------------------------------------------------------
# Baseline aggregators
# --------------------------------------------------------------------------
def fedavg(client_states, client_sizes):
    return sd_weighted_sum(client_states, client_sizes)


def fednova(client_states, client_sizes, local_steps, global_state):
    """
    FedNova (Wang et al. 2020): normalize each client's update by its number
    of local steps before averaging, then rescale by the effective tau.
    """
    w = np.asarray(client_sizes, dtype=np.float64)
    w = w / w.sum()
    taus = np.asarray(local_steps, dtype=np.float64)
    tau_eff = float((w * taus).sum())

    norm_updates = []
    for sd, tau in zip(client_states, taus):
        d = sd_sub(sd, global_state)
        norm_updates.append(OrderedDict((k, v / max(tau, 1.0)) for k, v in d.items()))

    agg = sd_weighted_sum(norm_updates, w)
    return OrderedDict(
        (k, global_state[k].to(torch.float32) + tau_eff * agg[k]) for k in global_state
    )


def scaffold_server_update(global_state, client_states, client_sizes, server_lr=1.0):
    """
    SCAFFOLD server step. Control-variate bookkeeping lives in the trainer;
    this applies the averaged corrected update to the global model.
    """
    avg = sd_weighted_sum(client_states, client_sizes)
    delta = sd_sub(avg, global_state)
    return sd_add(global_state, delta, scale=server_lr)


def ifca_assign(client_states, cluster_centers, client_eval_fn) -> np.ndarray:
    """
    IFCA (Ghosh et al. 2020): each client picks the cluster model that gives
    it the lowest local loss. client_eval_fn(client_idx, state) -> loss.
    """
    n_clients = len(client_states)
    assign = np.zeros(n_clients, dtype=int)
    for i in range(n_clients):
        losses = [client_eval_fn(i, center) for center in cluster_centers]
        assign[i] = int(np.argmin(losses))
    return assign


def cfl_bipartition(client_updates: List[dict]) -> Tuple[np.ndarray, float]:
    """
    CFL (Sattler et al. 2021): split clients into two groups by the cosine
    similarity of their weight updates, using the standard bipartition on
    the similarity matrix. Returns (labels, max_cross_similarity).
    """
    from sklearn.cluster import AgglomerativeClustering

    flat = torch.stack([sd_flat(u) for u in client_updates]).cpu().numpy()
    norms = np.maximum(np.linalg.norm(flat, axis=1, keepdims=True), 1e-12)
    unit = flat / norms
    sim = unit @ unit.T
    dist = np.clip(1.0 - sim, 0.0, 2.0)
    np.fill_diagonal(dist, 0.0)

    if flat.shape[0] < 2:
        return np.zeros(flat.shape[0], dtype=int), 1.0

    labels = AgglomerativeClustering(
        n_clusters=2, metric="precomputed", linkage="complete"
    ).fit_predict(dist)

    cross = [
        sim[i, j]
        for i in range(len(labels))
        for j in range(len(labels))
        if labels[i] != labels[j]
    ]
    return labels, (max(cross) if cross else 1.0)
