"""
Figure generation from real run logs.

Every figure here is built from results/**.jsonl. If the runs are absent the
call raises MissingRuns rather than drawing a plausible-looking curve.
Convergence bands are the actual across-seed spread, not a smoothing artifact.
"""
from __future__ import annotations

import os
from typing import Dict, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np

from .analyze import PRETTY, MissingRuns, aggregate_seeds, load_run

for _f in fm.findSystemFonts():
    if "LiberationSerif" in _f:
        fm.fontManager.addfont(_f)

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
    "font.size": 9, "axes.titlesize": 9, "axes.labelsize": 9,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 7.5,
    "axes.linewidth": 0.8, "lines.linewidth": 1.4,
    "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.dpi": 600,
})

COLORS = {
    "local_only": "#7f7f7f", "fedavg": "#1f77b4", "fedprox": "#ff7f0e",
    "fednova": "#2ca02c", "scaffold": "#d62728", "edge_avg": "#9467bd",
    "ifca": "#8c564b", "cfl": "#e377c2", "dcfl": "#000000",
}
STYLES = {
    "local_only": (0, (1, 1)), "fedavg": "--", "fedprox": "-.",
    "fednova": (0, (3, 1, 1, 1)), "scaffold": (0, (5, 1)), "edge_avg": ":",
    "ifca": (0, (4, 1, 1, 1)), "cfl": (0, (2, 1)), "dcfl": "-",
}


def _curve_matrix(root, dataset, scenario, method, seeds):
    """Stack per-seed accuracy curves -> (n_seeds, n_rounds). Raises if missing."""
    curves = []
    for s in seeds:
        rec = load_run(root, dataset, scenario, method, s)
        accs = [(r["round"], r["global_acc"]) for r in rec if "global_acc" in r]
        if not accs:
            raise MissingRuns(f"no evaluated rounds in {dataset}/{scenario}/{method}/seed{s}")
        curves.append([a for _, a in accs])
    n = min(len(c) for c in curves)
    rounds = [r for r, _ in
              [(x["round"], x["global_acc"]) for x in load_run(root, dataset, scenario, method, seeds[0])
               if "global_acc" in x]][:n]
    return np.asarray(rounds), np.vstack([c[:n] for c in curves])


def convergence_figure(root, dataset, scenario, methods, seeds, out_path,
                       target_acc: float = 80.0, show_band: bool = True):
    fig, ax = plt.subplots(figsize=(3.45, 2.6))
    for m in methods:
        rounds, mat = _curve_matrix(root, dataset, scenario, m, seeds)
        mean = mat.mean(axis=0)
        ax.plot(rounds, mean, label=PRETTY.get(m, m), color=COLORS.get(m, None),
                linestyle=STYLES.get(m, "-"),
                linewidth=2.0 if m == "dcfl" else 1.2,
                zorder=5 if m == "dcfl" else 3)
        if show_band and mat.shape[0] > 1:
            sd = mat.std(axis=0, ddof=1)
            ax.fill_between(rounds, mean - sd, mean + sd, color=COLORS.get(m, None),
                            alpha=0.15, linewidth=0, zorder=2)
    ax.axhline(target_acc, color="gray", linewidth=0.7, linestyle=(0, (2, 2)), zorder=1)
    ax.text(rounds[0], target_acc + 0.6, f"{target_acc:.0f}% target",
            fontsize=6.5, color="dimgray")
    ax.set_xlabel("Communication Rounds")
    ax.set_ylabel("Global Test Accuracy (%)")
    ax.set_title(f"Convergence, {scenario} ({dataset.upper()}), mean $\\pm$ s.d. over "
                 f"{len(seeds)} seeds", fontsize=8.2)
    ax.grid(True, linewidth=0.4, alpha=0.4)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    ax.legend(loc="lower right", ncol=2, frameon=False, columnspacing=1.0, handlelength=2.2)
    fig.tight_layout(pad=0.4)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, bbox_inches="tight")
    fig.savefig(os.path.splitext(out_path)[0] + ".png", dpi=600, bbox_inches="tight")
    plt.close(fig)
    return out_path


def fairness_figure(root, dataset, scenarios, methods, seeds, out_path,
                    threshold: float | None = 2.0):
    fig, ax = plt.subplots(figsize=(3.45, 2.9))
    x = np.arange(len(methods))
    width = 0.8 / len(scenarios)
    shades = plt.cm.Blues(np.linspace(0.35, 0.85, len(scenarios)))
    for i, sc in enumerate(scenarios):
        means, errs = [], []
        for m in methods:
            c = aggregate_seeds(root, dataset, sc, m, seeds, metric="fairness")
            means.append(c.mean); errs.append(c.std)
        ax.bar(x + (i - (len(scenarios) - 1) / 2) * width, means, width, yerr=errs,
               capsize=2.2, color=shades[i], edgecolor="black", linewidth=0.5,
               error_kw=dict(elinewidth=0.7, capthick=0.7), label=sc)
    if threshold is not None:
        ax.axhline(threshold, color="#c00000", linewidth=0.9, linestyle="--", zorder=1)
    ax.set_xticks(x)
    ax.set_xticklabels([PRETTY.get(m, m) for m in methods], rotation=20, ha="right")
    ax.set_ylabel(r"Fairness Index ($\sigma_A$)")
    ax.set_title(f"Fairness across scenarios ({dataset.upper()}), {len(seeds)} seeds",
                 fontsize=8.2)
    ax.grid(True, axis="y", linewidth=0.4, alpha=0.4); ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    ax.legend(frameon=False, ncol=len(scenarios), fontsize=6.6,
              loc="upper left", bbox_to_anchor=(-0.02, 1.14))
    fig.tight_layout(pad=0.4)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, bbox_inches="tight")
    fig.savefig(os.path.splitext(out_path)[0] + ".png", dpi=600, bbox_inches="tight")
    plt.close(fig)
    return out_path


def scalability_figure(root, dataset, scenario, method, seeds, client_counts,
                       out_path):
    """
    Accuracy and wall-clock vs. number of clients K. Requires runs performed
    at each K (results root must contain them, e.g. root_K20/...).
    """
    fig, ax1 = plt.subplots(figsize=(3.45, 2.5))
    accs, errs, secs = [], [], []
    for K in client_counts:
        r = f"{root}_K{K}"
        c = aggregate_seeds(r, dataset, scenario, method, seeds, "acc")
        t = aggregate_seeds(r, dataset, scenario, method, seeds, "round_seconds")
        accs.append(c.mean); errs.append(c.std); secs.append(t.mean)
    ax1.errorbar(client_counts, accs, yerr=errs, marker="o", color="#1f77b4",
                 capsize=2.5, linewidth=1.3)
    ax1.set_xlabel("Number of clients $K$")
    ax1.set_ylabel("Final accuracy (%)", color="#1f77b4")
    ax1.tick_params(axis="y", labelcolor="#1f77b4")
    ax2 = ax1.twinx()
    ax2.plot(client_counts, secs, marker="s", color="#c0392b", linestyle="--", linewidth=1.2)
    ax2.set_ylabel("Seconds / round", color="#c0392b")
    ax2.tick_params(axis="y", labelcolor="#c0392b")
    ax1.set_title(f"Scalability of {PRETTY.get(method, method)} ({scenario})", fontsize=8.2)
    ax1.grid(True, linewidth=0.4, alpha=0.4)
    fig.tight_layout(pad=0.4)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, bbox_inches="tight")
    fig.savefig(os.path.splitext(out_path)[0] + ".png", dpi=600, bbox_inches="tight")
    plt.close(fig)
    return out_path


def privacy_ablation_figure(root_pattern, dataset, scenario, method, seeds,
                            epsilons, out_path):
    """Accuracy vs. privacy budget epsilon. root_pattern like 'results_eps{eps}'."""
    fig, ax = plt.subplots(figsize=(3.45, 2.4))
    means, errs = [], []
    for e in epsilons:
        r = root_pattern.format(eps=str(e).replace(".", "p"))
        c = aggregate_seeds(r, dataset, scenario, method, seeds, "acc")
        means.append(c.mean); errs.append(c.std)
    ax.errorbar(range(len(epsilons)), means, yerr=errs, marker="o",
                color="#5a3b8a", capsize=2.5, linewidth=1.3)
    ax.set_xticks(range(len(epsilons)))
    ax.set_xticklabels([("no DP" if e is None else f"{e}") for e in epsilons])
    ax.set_xlabel(r"Privacy budget $\epsilon$")
    ax.set_ylabel("Final accuracy (%)")
    ax.set_title(f"Privacy-utility trade-off ({scenario})", fontsize=8.2)
    ax.grid(True, linewidth=0.4, alpha=0.4)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    fig.tight_layout(pad=0.4)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, bbox_inches="tight")
    fig.savefig(os.path.splitext(out_path)[0] + ".png", dpi=600, bbox_inches="tight")
    plt.close(fig)
    return out_path
