"""
Federated simulation runner.

Writes one JSONL record per communication round to
    results/<dataset>/<scenario>/<method>/seed<seed>.jsonl
plus a run-level meta.json capturing the exact config, git commit and
partition spec. The analysis scripts read ONLY these files, so every number
in the paper is traceable back to a specific run.
"""
from __future__ import annotations

import json
import os
import platform
import subprocess
import time
from collections import OrderedDict
from dataclasses import dataclass, asdict, field
from typing import Dict, List

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from .algorithms import (
    cluster_by_signature,
    cluster_quality_from_losses,
    cosine_similarity_matrix,
    distribution_signature,
    fedavg,
    fednova,
    scaffold_server_update,
    sd_sub,
    sd_weighted_sum,
    two_level_aggregate,
    ifca_assign,
    cfl_bipartition,
)
from .engine import LocalTrainer, build_model, evaluate, feature_stats_for_signature
from .partition import partition, partition_report

METHODS = [
    "local_only", "fedavg", "fedprox", "fednova", "scaffold",
    "edge_avg", "ifca", "cfl", "dcfl",
]


@dataclass
class Config:
    dataset: str = "pima"
    model: str = "mlp"
    method: str = "dcfl"
    scenario: str = "S2"
    n_clients: int = 5
    rounds: int = 200
    local_epochs: int = 5
    batch_size: int = 32
    lr: float = 0.01
    momentum: float = 0.9
    prox_mu: float = 0.01
    cluster_interval: int = 5
    epsilon: float | None = 1.0
    seed: int = 7
    device: str = "cpu"
    out_root: str = "results"
    eval_every: int = 1
    target_acc: float = 80.0
    notes: str = ""
    extra: Dict = field(default_factory=dict)


def _git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL
        ).decode().strip()
    except Exception:
        return "unknown"


def set_all_seeds(seed: int):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def run(cfg: Config, train_ds, test_ds, train_labels: np.ndarray, n_classes: int,
        in_dim: int | None = None, client_test_indices: List[np.ndarray] | None = None):
    """
    Execute one (dataset, scenario, method, seed) run and stream results to disk.
    """
    if cfg.method not in METHODS:
        raise KeyError(f"unknown method {cfg.method!r}; expected one of {METHODS}")

    set_all_seeds(cfg.seed)
    out_dir = os.path.join(cfg.out_root, cfg.dataset, cfg.scenario, cfg.method)
    os.makedirs(out_dir, exist_ok=True)
    log_path = os.path.join(out_dir, f"seed{cfg.seed}.jsonl")
    meta_path = os.path.join(out_dir, f"seed{cfg.seed}.meta.json")

    parts, spec = partition(train_labels, cfg.scenario, cfg.n_clients, cfg.seed)
    report = partition_report(train_labels, parts)

    with open(meta_path, "w") as f:
        json.dump(
            dict(
                config=asdict(cfg),
                partition=asdict(spec),
                partition_report=report,
                git_commit=_git_commit(),
                torch=torch.__version__,
                platform=platform.platform(),
                started=time.strftime("%Y-%m-%dT%H:%M:%S"),
            ),
            f, indent=2,
        )

    loaders = [
        DataLoader(Subset(train_ds, idx.tolist()), batch_size=cfg.batch_size,
                   shuffle=True, drop_last=False)
        for idx in parts
    ]
    test_loader = DataLoader(test_ds, batch_size=256, shuffle=False)
    per_client_test = None
    if client_test_indices is not None:
        per_client_test = [
            DataLoader(Subset(test_ds, idx.tolist()), batch_size=256, shuffle=False)
            for idx in client_test_indices
        ]

    model = build_model(cfg.model, n_classes, in_dim)
    global_state = OrderedDict((k, v.detach().cpu().clone())
                               for k, v in model.state_dict().items())

    trainer = LocalTrainer(
        model=model, device=cfg.device, lr=cfg.lr, momentum=cfg.momentum,
        local_epochs=cfg.local_epochs,
        prox_mu=(cfg.prox_mu if cfg.method == "fedprox" else 0.0),
        use_scaffold=(cfg.method == "scaffold"),
    )

    # persistent per-method state
    c_global = OrderedDict((k, torch.zeros_like(v, dtype=torch.float32))
                           for k, v in global_state.items())
    c_locals = [OrderedDict((k, torch.zeros_like(v, dtype=torch.float32))
                            for k, v in global_state.items())
                for _ in range(cfg.n_clients)]
    local_states = [OrderedDict((k, v.clone()) for k, v in global_state.items())
                    for _ in range(cfg.n_clients)]      # local_only / ifca
    cluster_labels = np.zeros(cfg.n_clients, dtype=int)  # dcfl / cfl
    ifca_centers = None
    reached_target_round = None

    rng = np.random.default_rng(cfg.seed)
    fout = open(log_path, "w")

    for rnd in range(1, cfg.rounds + 1):
        t_round = time.time()
        results, sizes, steps, losses = [], [], [], []

        for ci in range(cfg.n_clients):
            if cfg.method == "local_only":
                start = local_states[ci]
            elif cfg.method == "ifca" and ifca_centers is not None:
                start = ifca_centers[int(cluster_labels[ci])]
            else:
                start = global_state

            res = trainer.train(
                start, loaders[ci],
                c_global=c_global if cfg.method == "scaffold" else None,
                c_local=c_locals[ci] if cfg.method == "scaffold" else None,
            )
            results.append(res)
            sizes.append(max(1, len(parts[ci])))
            steps.append(res.steps)
            losses.append(res.train_loss)
            if cfg.method == "local_only":
                local_states[ci] = res.state
            if cfg.method == "scaffold" and res.c_delta is not None:
                for k in c_locals[ci]:
                    c_locals[ci][k] = c_locals[ci][k] + res.c_delta[k]

        states = [r.state for r in results]
        info: Dict = {}

        # ---------------- aggregation ----------------
        if cfg.method == "local_only":
            pass  # no aggregation
        elif cfg.method in ("fedavg", "edge_avg"):
            # Edge-Avg differs operationally (edge preaggregation), not in the
            # averaging rule at this simulation granularity.
            global_state = fedavg(states, sizes)
        elif cfg.method == "fedprox":
            global_state = fedavg(states, sizes)
        elif cfg.method == "fednova":
            global_state = fednova(states, sizes, steps, global_state)
        elif cfg.method == "scaffold":
            global_state = scaffold_server_update(global_state, states, sizes)
            deltas = [r.c_delta for r in results if r.c_delta is not None]
            if deltas:
                for k in c_global:
                    c_global[k] = c_global[k] + sum(d[k] for d in deltas) / cfg.n_clients
        elif cfg.method == "cfl":
            updates = [sd_sub(s, global_state) for s in states]
            cluster_labels, cross = cfl_bipartition(updates)
            info["cfl_max_cross_similarity"] = float(cross)
            global_state, clusters = two_level_aggregate(states, sizes, cluster_labels, None)
            info["clusters"] = [int(c) for c in clusters]
        elif cfg.method == "ifca":
            if ifca_centers is None:
                m = max(2, min(3, cfg.n_clients - 1))
                ifca_centers = [
                    OrderedDict((k, v.clone() + 0.01 * torch.randn_like(v.float()))
                                for k, v in global_state.items())
                    for _ in range(m)
                ]
            for c in range(len(ifca_centers)):
                members = [i for i in range(cfg.n_clients) if int(cluster_labels[i]) == c]
                if members:
                    ifca_centers[c] = sd_weighted_sum([states[i] for i in members],
                                                      [sizes[i] for i in members])

            def _eval_center(i: int, center) -> float:
                _, l = evaluate(model, center, loaders[i], cfg.device)
                return l

            cluster_labels = ifca_assign(states, ifca_centers, _eval_center)
            info["ifca_assignment"] = cluster_labels.tolist()
            global_state = sd_weighted_sum(
                ifca_centers, [max(1, int((cluster_labels == c).sum()))
                               for c in range(len(ifca_centers))]
            )
        elif cfg.method == "dcfl":
            if (rnd - 1) % cfg.cluster_interval == 0:
                sigs = []
                for ci in range(cfg.n_clients):
                    y = train_labels[parts[ci]]
                    fm, fs = feature_stats_for_signature(loaders[ci])
                    sigs.append(
                        distribution_signature(
                            y, fm, fs, n_classes,
                            epsilon=cfg.epsilon,
                            rng=np.random.default_rng(cfg.seed * 1000 + rnd * 10 + ci),
                        )
                    )
                sigs = np.vstack(sigs)
                cluster_labels = cluster_by_signature(sigs)
                info["reclustered"] = True
                info["cluster_labels"] = cluster_labels.tolist()
                info["mean_abs_cosine"] = float(
                    np.abs(cosine_similarity_matrix(sigs)).mean()
                )
            q = cluster_quality_from_losses(cluster_labels, losses)
            global_state, clusters = two_level_aggregate(states, sizes, cluster_labels, q)
            info["clusters"] = [int(c) for c in clusters]
            info["cluster_quality"] = {str(k): float(v) for k, v in q.items()}
        else:
            raise AssertionError(cfg.method)

        # ---------------- evaluation ----------------
        rec = dict(
            round=rnd,
            method=cfg.method,
            scenario=cfg.scenario,
            seed=cfg.seed,
            dataset=cfg.dataset,
            train_loss=float(np.mean(losses)),
            round_seconds=float(time.time() - t_round),
            client_seconds=[float(r.seconds) for r in results],
            client_sizes=[int(s) for s in sizes],
            **info,
        )

        if rnd % cfg.eval_every == 0 or rnd == cfg.rounds:
            if cfg.method == "local_only":
                accs, ls = [], []
                for ci in range(cfg.n_clients):
                    a, l = evaluate(model, local_states[ci], test_loader, cfg.device)
                    accs.append(a); ls.append(l)
                rec["global_acc"] = float(np.mean(accs))
                rec["global_loss"] = float(np.mean(ls))
            else:
                a, l = evaluate(model, global_state, test_loader, cfg.device)
                rec["global_acc"], rec["global_loss"] = float(a), float(l)

            if per_client_test is not None:
                per = []
                for ci, tl in enumerate(per_client_test):
                    st = local_states[ci] if cfg.method == "local_only" else global_state
                    a, _ = evaluate(model, st, tl, cfg.device)
                    per.append(float(a))
                rec["per_client_acc"] = per
                rec["fairness_sigma"] = float(np.std(per))

            if (reached_target_round is None
                    and rec.get("global_acc", 0.0) >= cfg.target_acc):
                reached_target_round = rnd
            rec["reached_target_round"] = reached_target_round

        fout.write(json.dumps(rec) + "\n")
        fout.flush()

    fout.close()
    with open(meta_path) as f:
        meta = json.load(f)
    meta["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    meta["reached_target_round"] = reached_target_round
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    return log_path
