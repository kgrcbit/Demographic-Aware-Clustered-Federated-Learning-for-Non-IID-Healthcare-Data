"""
Analysis: turn run logs into the numbers and tables that go in the paper.

Hard rule enforced here: this module NEVER invents, interpolates or
back-fills a value. If a (dataset, scenario, method, seed) run is missing,
it raises MissingRuns listing exactly what to run. A table can only be
produced from runs that actually happened.

That is deliberate. It means a figure or table in the paper cannot exist
unless the corresponding experiment exists on disk.
"""
from __future__ import annotations

import glob
import json
import os
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence

import numpy as np
from scipy import stats


class MissingRuns(RuntimeError):
    pass


PRETTY = {
    "local_only": "Local-Only",
    "fedavg": "FedAvg",
    "fedprox": "FedProx",
    "fednova": "FedNova",
    "scaffold": "SCAFFOLD",
    "edge_avg": "Edge-Avg",
    "ifca": "IFCA",
    "cfl": "CFL",
    "dcfl": "DC-FL",
}


def load_run(root: str, dataset: str, scenario: str, method: str, seed: int) -> List[dict]:
    path = os.path.join(root, dataset, scenario, method, f"seed{seed}.jsonl")
    if not os.path.exists(path):
        raise MissingRuns(f"missing run log: {path}")
    with open(path) as f:
        return [json.loads(line) for line in f if line.strip()]


def final_accuracy(records: Sequence[dict], last_k: int = 5) -> float:
    """Mean global accuracy over the last `last_k` evaluated rounds."""
    accs = [r["global_acc"] for r in records if "global_acc" in r]
    if not accs:
        raise MissingRuns("run contains no evaluated rounds (no global_acc)")
    return float(np.mean(accs[-last_k:]))


def final_metric(records: Sequence[dict], key: str, last_k: int = 5) -> float:
    """
    Mean of any logged metric over the last `last_k` evaluated rounds.

    Use key='balanced_acc' or 'macro_f1' on imbalanced datasets. Plain
    accuracy cannot distinguish a real model from a majority-class constant
    predictor when one class dominates.
    """
    vals = [r[key] for r in records if key in r]
    if not vals:
        raise MissingRuns(
            f"run has no '{key}' logged; it predates the imbalance-aware "
            f"metrics and must be re-run")
    return float(np.mean(vals[-last_k:]))


def final_fairness(records: Sequence[dict], last_k: int = 5) -> float:
    vals = [r["fairness_sigma"] for r in records if "fairness_sigma" in r]
    if not vals:
        raise MissingRuns(
            "run has no per-client accuracies; re-run with client_test_indices "
            "so fairness_sigma is recorded"
        )
    return float(np.mean(vals[-last_k:]))


def rounds_to_target(records: Sequence[dict]) -> int | None:
    for r in records:
        if r.get("reached_target_round"):
            return int(r["reached_target_round"])
    return None


def mean_round_seconds(records: Sequence[dict]) -> float:
    vals = [r["round_seconds"] for r in records if "round_seconds" in r]
    return float(np.mean(vals)) if vals else float("nan")


@dataclass
class Cell:
    mean: float
    std: float
    n: int
    values: List[float]

    def fmt(self, prec: int = 1, with_std: bool = True) -> str:
        if with_std and self.n > 1:
            return f"{self.mean:.{prec}f} $\\pm$ {self.std:.{prec}f}"
        return f"{self.mean:.{prec}f}"


def aggregate_seeds(root: str, dataset: str, scenario: str, method: str,
                    seeds: Iterable[int], metric: str = "acc") -> Cell:
    vals = []
    missing = []
    for s in seeds:
        try:
            rec = load_run(root, dataset, scenario, method, s)
            if metric == "acc":
                vals.append(final_accuracy(rec))
            elif metric == "fairness":
                vals.append(final_fairness(rec))
            elif metric == "round_seconds":
                vals.append(mean_round_seconds(rec))
            elif metric in ("balanced_acc", "macro_f1", "collapse_frac"):
                vals.append(final_metric(rec, metric))
            else:
                raise KeyError(metric)
        except MissingRuns as e:
            missing.append(str(e))
    if missing:
        raise MissingRuns(
            f"{len(missing)} missing/incomplete run(s) for "
            f"{dataset}/{scenario}/{method}:\n  " + "\n  ".join(missing)
        )
    arr = np.asarray(vals, dtype=float)
    return Cell(float(arr.mean()), float(arr.std(ddof=1)) if len(arr) > 1 else 0.0,
                len(arr), arr.tolist())


def paired_test(root: str, dataset: str, scenario: str, method_a: str,
                method_b: str, seeds: Sequence[int]) -> dict:
    """
    Paired two-tailed t-test AND Wilcoxon signed-rank between two methods,
    matched by seed. Reports the power caveat when n is small.
    """
    a = aggregate_seeds(root, dataset, scenario, method_a, seeds).values
    b = aggregate_seeds(root, dataset, scenario, method_b, seeds).values
    a, b = np.asarray(a), np.asarray(b)
    t_stat, t_p = stats.ttest_rel(a, b)
    out = dict(
        method_a=method_a, method_b=method_b, n=len(a),
        mean_a=float(a.mean()), mean_b=float(b.mean()),
        mean_diff=float((a - b).mean()),
        t_stat=float(t_stat), t_p=float(t_p),
        df=len(a) - 1,
    )
    # Cohen's d for paired samples
    d = (a - b)
    out["cohens_d"] = float(d.mean() / d.std(ddof=1)) if len(d) > 1 and d.std(ddof=1) > 0 else float("nan")
    if len(a) >= 6:
        try:
            w_stat, w_p = stats.wilcoxon(a, b)
            out["wilcoxon_stat"], out["wilcoxon_p"] = float(w_stat), float(w_p)
        except Exception:
            pass
    else:
        out["wilcoxon_note"] = (
            f"n={len(a)} is too small for a meaningful Wilcoxon signed-rank test "
            f"(needs >= 6 pairs); report the t-test with its df and treat p as indicative."
        )
    if len(a) < 5:
        out["power_warning"] = (
            f"n={len(a)} seeds gives df={len(a)-1}. This is below the 5-10 runs "
            f"a journal reviewer will expect; increase seed count before submission."
        )
    return out


def paired_test_metric(root: str, dataset: str, scenario: str, method_a: str,
                       method_b: str, seeds: Sequence[int], metric: str) -> dict:
    """Paired two-tailed t-test on any logged metric (e.g. balanced_acc)."""
    a = np.asarray(aggregate_seeds(root, dataset, scenario, method_a, seeds, metric).values)
    b = np.asarray(aggregate_seeds(root, dataset, scenario, method_b, seeds, metric).values)
    t_stat, t_p = stats.ttest_rel(a, b)
    return dict(metric=metric, n=len(a), mean_a=float(a.mean()), mean_b=float(b.mean()),
                mean_diff=float((a - b).mean()), t_stat=float(t_stat), t_p=float(t_p),
                df=len(a) - 1)


def ci95(cell: Cell) -> tuple[float, float]:
    """95% CI of the mean using the t distribution (correct for small n)."""
    if cell.n < 2:
        return (float("nan"), float("nan"))
    sem = cell.std / np.sqrt(cell.n)
    h = sem * stats.t.ppf(0.975, cell.n - 1)
    return (cell.mean - h, cell.mean + h)


# --------------------------------------------------------------------------
# LaTeX emitters
# --------------------------------------------------------------------------
def latex_accuracy_table(root: str, dataset: str, scenarios: Sequence[str],
                         methods: Sequence[str], seeds: Sequence[int],
                         caption: str, label: str, with_std: bool = True) -> str:
    cols = "l" + "c" * len(scenarios)
    lines = [
        r"\begin{table}[t]", r"\centering", f"\\caption{{{caption}}}",
        f"\\label{{{label}}}", r"\renewcommand{\arraystretch}{1.15}",
        f"\\begin{{tabular}}{{{cols}}}", r"\toprule",
        "\\textbf{Method} & " + " & ".join(f"\\textbf{{{s}}}" for s in scenarios) + r" \\",
        r"\midrule",
    ]
    for m in methods:
        cells = []
        for sc in scenarios:
            c = aggregate_seeds(root, dataset, sc, m, seeds, "acc")
            cells.append(c.fmt(1, with_std))
        name = PRETTY.get(m, m)
        if m == "dcfl":
            name = f"\\textbf{{{name}}}"
            cells = [f"\\textbf{{{c}}}" for c in cells]
        lines.append(name + " & " + " & ".join(cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def latex_significance_table(root: str, dataset: str, scenario: str,
                             methods: Sequence[str], seeds: Sequence[int],
                             reference: str = "dcfl",
                             caption: str = "", label: str = "tab:significance") -> str:
    lines = [
        r"\begin{table}[t]", r"\centering", f"\\caption{{{caption}}}",
        f"\\label{{{label}}}", r"\renewcommand{\arraystretch}{1.15}",
        r"\begin{tabular}{lccc}", r"\toprule",
        r"\textbf{Method} & \textbf{Accuracy (\%)} & \textbf{95\% CI} & "
        r"\textbf{$p$ vs. " + PRETTY.get(reference, reference) + r"} \\",
        r"\midrule",
    ]
    for m in methods:
        c = aggregate_seeds(root, dataset, scenario, m, seeds, "acc")
        lo, hi = ci95(c)
        if m == reference:
            lines.append(
                f"\\textbf{{{PRETTY.get(m,m)}}} & \\textbf{{{c.mean:.1f} $\\pm$ {c.std:.1f}}} & "
                f"[{lo:.1f}, {hi:.1f}] & --- \\\\"
            )
            continue
        t = paired_test(root, dataset, scenario, reference, m, seeds)
        p = t["t_p"]
        p_str = "$<$0.001" if p < 0.001 else f"{p:.3f}"
        lines.append(
            f"{PRETTY.get(m,m)} & {c.mean:.1f} $\\pm$ {c.std:.1f} & "
            f"[{lo:.1f}, {hi:.1f}] & {p_str} \\\\"
        )
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def coverage_report(root: str, datasets: Sequence[str], scenarios: Sequence[str],
                    methods: Sequence[str], seeds: Sequence[int]) -> dict:
    """
    What exists vs. what the paper needs. Run this BEFORE writing tables so
    you know exactly which experiments are still outstanding.
    """
    have, missing = [], []
    for d in datasets:
        for sc in scenarios:
            for m in methods:
                for s in seeds:
                    p = os.path.join(root, d, sc, m, f"seed{s}.jsonl")
                    (have if os.path.exists(p) else missing).append(
                        dict(dataset=d, scenario=sc, method=m, seed=s, path=p)
                    )
    return dict(
        n_expected=len(have) + len(missing),
        n_have=len(have),
        n_missing=len(missing),
        pct_complete=100.0 * len(have) / max(1, len(have) + len(missing)),
        missing=missing,
    )
