"""Fig 1: DC-FL framework schematic (single round)."""
import os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
for f in fm.findSystemFonts():
    if "LiberationSerif" in f: fm.fontManager.addfont(f)
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],
 "pdf.fonttype":42,"savefig.dpi":600})

fig,ax=plt.subplots(figsize=(6.6,2.5)); ax.set_xlim(0,100); ax.set_ylim(0,34); ax.axis("off")
def box(x,y,w,h,title,body,ec,fc):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0,rounding_size=1.0",
        lw=1.0,edgecolor=ec,facecolor=fc,zorder=2))
    ax.text(x+w/2,y+h-2.0,title,ha="center",va="center",fontsize=6.6,weight="bold",color=ec,zorder=4)
    for i,ln in enumerate(body):
        ax.text(x+w/2,y+h-4.6-i*2.5,ln,ha="center",va="center",fontsize=5.6,color="#111",zorder=4)
def arrow(x0,x1,y,txt=None):
    ax.add_patch(FancyArrowPatch((x0,y),(x1,y),arrowstyle="-|>",mutation_scale=9,
        lw=1.1,color="#333",zorder=3))
    if txt: ax.text((x0+x1)/2,y+1.4,txt,ha="center",fontsize=5.4,style="italic",color="#333")

W,H,Y=20,17,11
box(1,Y,W,H,"1. Local training",
    ["Institution $k$ trains","$w_k$ on $\\mathcal{D}_k$","$E$ local epochs"],"#3b6ea5","#eaf1f8")
box(26,Y,W,H,"2. Signature + DP",
    ["class proportions","+ feature stats","+ Laplace$(\\Delta s/\\epsilon)$","per-component $\\Delta s$"],"#c07a1e","#fbeedd")
box(51,Y,W,H,"3. Clustering",
    ["cosine similarity","agglomerative,","silhouette-selected","every $\\tau$ rounds"],"#5a3b8a","#efe6f7")
box(76,Y,W,H,"4. Two-level agg.",
    ["intra: size-weighted","inter: $\\beta_m\\propto|G_m|Q_m$","singleton guard"],"#2c8a52","#e3f3ea")
arrow(21,26,Y+H/2,"$\\tilde s_k$")
arrow(46,51,Y+H/2,"$\\{\\tilde s_k\\}$")
arrow(71,76,Y+H/2,"$\\{G_m\\}$")
a=FancyArrowPatch((86,Y),(11,Y),connectionstyle="arc3,rad=0.30",arrowstyle="-|>",
    mutation_scale=9,lw=1.0,color="#c0392b",ls=(0,(4,2)),zorder=3)
ax.add_patch(a)
ax.text(48,1.2,"broadcast $w^{t+1}$ to all institutions",ha="center",fontsize=5.8,
        style="italic",color="#c0392b")
ax.text(48,31.5,"One communication round",ha="center",fontsize=7.4,weight="bold",color="#222")
fig.tight_layout(pad=0.3)
os.makedirs("figs",exist_ok=True)
fig.savefig("figs/fig_framework.pdf",bbox_inches="tight")
fig.savefig("figs/fig_framework.png",dpi=600,bbox_inches="tight")
print("wrote figs/fig_framework.pdf")
