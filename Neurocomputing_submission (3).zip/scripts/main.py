#!/usr/bin/env python3
"""
Command line entry point.

  # one run
  python scripts/main.py run --dataset pima --data-path data/diabetes.csv \
      --method dcfl --scenario S2 --seed 7 --rounds 200

  # full sweep (all methods x scenarios x seeds)
  python scripts/main.py sweep --dataset pima --data-path data/diabetes.csv \
      --seeds 7 23 42 101 202 --rounds 200

  # what still needs running
  python scripts/main.py coverage --dataset pima --seeds 7 23 42 101 202

  # tables + figures, strictly from logs on disk
  python scripts/main.py report --dataset pima --seeds 7 23 42 101 202
"""
from __future__ import annotations

import argparse
import itertools
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dcfl.analyze import (  # noqa: E402
    MissingRuns, coverage_report, latex_accuracy_table, latex_significance_table,
)
from dcfl.partition import partition  # noqa: E402

# Methods list is needed for argparse choices but lives in run.py, which imports
# torch. Keep it duplicated here so `coverage`/`report` work without torch
# installed (they only read JSON logs).
METHODS = [
    "local_only", "fedavg", "fedprox", "fednova", "scaffold",
    "edge_avg", "ifca", "cfl", "dcfl",
]
SCENARIOS = ["IID", "S1", "S2", "S3", "S4"]


def _load(dataset: str, data_path: str, seed: int):
    # imported lazily: training needs torch, analysis does not
    from dcfl.datasets import load_image_folder, load_pima
    if dataset == "pima":
        return load_pima(data_path, seed=seed)
    if dataset in ("isic", "chestxray"):
        return load_image_folder(data_path, seed=seed)
    raise KeyError(dataset)


def _model_for(dataset: str) -> str:
    return {"pima": "mlp", "isic": "resnet18", "chestxray": "densenet121"}[dataset]


def cmd_run(a):
    from dcfl.datasets import make_client_test_indices
    from dcfl.run import Config, run

    train_ds, test_ds, train_labels, n_classes, in_dim = _load(a.dataset, a.data_path, a.seed)
    parts, _ = partition(train_labels, a.scenario, a.n_clients, a.seed)
    test_labels = np.array([int(test_ds[i][1]) for i in range(len(test_ds))])
    cti = make_client_test_indices(test_labels, parts, train_labels, seed=a.seed)

    cfg = Config(
        dataset=a.dataset, model=_model_for(a.dataset), method=a.method,
        scenario=a.scenario, n_clients=a.n_clients, rounds=a.rounds,
        local_epochs=a.local_epochs, batch_size=a.batch_size, lr=a.lr,
        epsilon=a.epsilon, seed=a.seed, device=a.device, out_root=a.out_root,
        eval_every=a.eval_every, target_acc=a.target_acc,
    )
    p = run(cfg, train_ds, test_ds, train_labels, n_classes, in_dim, cti)
    print(f"wrote {p}")


def cmd_sweep(a):
    combos = list(itertools.product(a.methods, a.scenarios, a.seeds))
    print(f"{len(combos)} runs queued")
    for i, (m, sc, s) in enumerate(combos, 1):
        out = os.path.join(a.out_root, a.dataset, sc, m, f"seed{s}.jsonl")
        if os.path.exists(out) and not a.overwrite:
            print(f"[{i}/{len(combos)}] skip (exists) {sc}/{m}/seed{s}")
            continue
        print(f"[{i}/{len(combos)}] {sc}/{m}/seed{s}")
        ns = argparse.Namespace(**vars(a))
        ns.method, ns.scenario, ns.seed = m, sc, s
        cmd_run(ns)


def cmd_coverage(a):
    rep = coverage_report(a.out_root, [a.dataset], a.scenarios, a.methods, a.seeds)
    print(f"{rep['n_have']}/{rep['n_expected']} runs present "
          f"({rep['pct_complete']:.1f}% complete)")
    if rep["missing"]:
        print("\nmissing:")
        for m in rep["missing"][:40]:
            print(f"  {m['scenario']:4s} {m['method']:11s} seed{m['seed']}")
        if len(rep["missing"]) > 40:
            print(f"  ... and {len(rep['missing'])-40} more")


def cmd_report(a):
    os.makedirs(a.tex_out, exist_ok=True)
    try:
        t1 = latex_accuracy_table(
            a.out_root, a.dataset, a.scenarios, a.methods, a.seeds,
            caption=f"Global test accuracy (\\%) on {a.dataset.upper()}, "
                    f"mean $\\pm$ s.d. over {len(a.seeds)} seeds.",
            label="tab:global_accuracy")
        open(os.path.join(a.tex_out, "table_accuracy.tex"), "w").write(t1)

        t2 = latex_significance_table(
            a.out_root, a.dataset, "S2", a.methods, a.seeds, reference="dcfl",
            caption=f"Statistical comparison under severe non-IID (S2), "
                    f"{a.dataset.upper()}, $n={len(a.seeds)}$ seeds. "
                    f"Paired two-tailed $t$-test against DC-FL.",
            label="tab:significance")
        open(os.path.join(a.tex_out, "table_significance.tex"), "w").write(t2)
        print(f"wrote LaTeX tables to {a.tex_out}/")
    except MissingRuns as e:
        print("REFUSING to emit tables -- experiments are incomplete:\n", e)
        print("\nRun `coverage` to see exactly what is missing.")
        return 1

    from dcfl.figures import convergence_figure, fairness_figure
    os.makedirs(a.fig_out, exist_ok=True)
    try:
        convergence_figure(a.out_root, a.dataset, "S2", a.methods, a.seeds,
                           os.path.join(a.fig_out, "fig_convergence.pdf"),
                           target_acc=a.target_acc)
        fairness_figure(a.out_root, a.dataset, ["S1", "S2", "S4"], a.methods, a.seeds,
                        os.path.join(a.fig_out, "fig_fairness.pdf"))
        print(f"wrote figures to {a.fig_out}/")
    except MissingRuns as e:
        print("figures skipped -- missing runs:\n", e)
    return 0


def build_parser():
    p = argparse.ArgumentParser(description="DC-FL experiments")
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--dataset", default="pima", choices=["pima", "isic", "chestxray"])
        sp.add_argument("--data-path", default="data/diabetes.csv")
        sp.add_argument("--n-clients", type=int, default=5)
        sp.add_argument("--rounds", type=int, default=200)
        sp.add_argument("--local-epochs", type=int, default=5)
        sp.add_argument("--batch-size", type=int, default=32)
        sp.add_argument("--lr", type=float, default=0.01)
        sp.add_argument("--epsilon", type=float, default=1.0)
        sp.add_argument("--device", default="cpu")
        sp.add_argument("--out-root", default="results")
        sp.add_argument("--eval-every", type=int, default=1)
        sp.add_argument("--target-acc", type=float, default=80.0)

    r = sub.add_parser("run"); common(r)
    r.add_argument("--method", default="dcfl", choices=METHODS)
    r.add_argument("--scenario", default="S2", choices=SCENARIOS)
    r.add_argument("--seed", type=int, default=7)
    r.set_defaults(func=cmd_run)

    s = sub.add_parser("sweep"); common(s)
    s.add_argument("--methods", nargs="+", default=METHODS)
    s.add_argument("--scenarios", nargs="+", default=SCENARIOS)
    s.add_argument("--seeds", nargs="+", type=int, default=[7, 23, 42, 101, 202])
    s.add_argument("--overwrite", action="store_true")
    s.set_defaults(func=cmd_sweep)

    c = sub.add_parser("coverage")
    c.add_argument("--dataset", default="pima")
    c.add_argument("--out-root", default="results")
    c.add_argument("--methods", nargs="+", default=METHODS)
    c.add_argument("--scenarios", nargs="+", default=SCENARIOS)
    c.add_argument("--seeds", nargs="+", type=int, default=[7, 23, 42, 101, 202])
    c.set_defaults(func=cmd_coverage)

    rp = sub.add_parser("report")
    rp.add_argument("--dataset", default="pima")
    rp.add_argument("--out-root", default="results")
    rp.add_argument("--methods", nargs="+", default=METHODS)
    rp.add_argument("--scenarios", nargs="+", default=SCENARIOS)
    rp.add_argument("--seeds", nargs="+", type=int, default=[7, 23, 42, 101, 202])
    rp.add_argument("--tex-out", default="paper/tables")
    rp.add_argument("--fig-out", default="paper/figures")
    rp.add_argument("--target-acc", type=float, default=80.0)
    rp.set_defaults(func=cmd_report)
    return p


if __name__ == "__main__":
    args = build_parser().parse_args()
    sys.exit(args.func(args) or 0)
