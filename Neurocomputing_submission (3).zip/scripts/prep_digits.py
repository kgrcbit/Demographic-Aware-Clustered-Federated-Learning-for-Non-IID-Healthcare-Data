import numpy as np
from sklearn.datasets import load_digits
def load(seed=0, test_frac=0.2):
    X, y = load_digits(return_X_y=True)
    X = X.astype(np.float64)
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(y))
    nte = int(round(test_frac*len(y)))
    te, tr = idx[:nte], idx[nte:]
    mu, sd = X[tr].mean(0), X[tr].std(0); sd[sd==0]=1.0
    Xs = (X-mu)/sd
    return Xs[tr], y[tr], Xs[te], y[te]
