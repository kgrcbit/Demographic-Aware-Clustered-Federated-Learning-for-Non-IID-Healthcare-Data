"""
DermaMNIST federated experiment.

DermaMNIST is HAM10000 at 28x28 with 7 lesion classes (10,015 images) -- the
same source collection ISIC 2019 is built from, so it is a genuine medical
multi-class test of the boundary condition, and small enough to run on CPU.

WHY THIS EXPERIMENT
-------------------
Pima (C=2) : DC-FL collapsed, -15.8 points vs FedAvg under S2.
Digits (C=10): no collapse, -1.4 points; the single seed whose partition gave
               one client a single class collapsed exactly as predicted.

The open question is whether the same holds on medical imaging. DermaMNIST
answers it directly.

USAGE
-----
    pip install medmnist
    python scripts/run_dermamnist.py              # downloads ~20 MB on first run
    python scripts/run_dermamnist.py --decisive   # S2 only, ~45 runs, faster

The first call downloads from Zenodo. If your network blocks Zenodo, fetch
dermamnist.npz manually and place it at ~/.medmnist/dermamnist.npz.

FEATURE REPRESENTATION
----------------------
Two modes:
  --raw   flatten 28x28x3 -> 2352-d pixels, PCA to --ndim (default).
          No pretrained weights involved; fully self-contained.
  --resnet  frozen ImageNet ResNet-18 features (needs torch/torchvision).
          Closer to the ISIC protocol but heavier.

State whichever you use in the paper. The raw+PCA mode is a classifier over
pixel features, not end-to-end fine-tuning, and should be described as such.
"""
from __future__ import annotations

import argparse
import itertools
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dcfl.partition import partition
from dcfl.datasets import make_client_test_indices
from dcfl.run_numpy import ConfigNP, run_np, METHODS
from dcfl.analyze import aggregate_seeds, paired_test, paired_test_metric

SCEN = ["IID", "S1", "S2", "S3", "S4"]


def load_dermamnist(ndim: int = 128, use_resnet: bool = False, seed: int = 0):
    """Returns Xtr, ytr, Xte, yte, n_classes. Train/test are DermaMNIST's own splits."""
    try:
        from medmnist import DermaMNIST
    except ImportError:
        sys.exit("pip install medmnist")

    tr = DermaMNIST(split="train", download=True)
    te = DermaMNIST(split="test", download=True)
    Xtr_img = np.asarray(tr.imgs)            # (7007, 28, 28, 3)
    Xte_img = np.asarray(te.imgs)            # (2005, 28, 28, 3)
    ytr = np.asarray(tr.labels).reshape(-1).astype(int)
    yte = np.asarray(te.labels).reshape(-1).astype(int)
    C = int(max(ytr.max(), yte.max())) + 1
    print(f"DermaMNIST: train {Xtr_img.shape}, test {Xte_img.shape}, {C} classes")
    print("train class counts:", np.bincount(ytr, minlength=C))

    if use_resnet:
        Xtr_f, Xte_f = _resnet_features(Xtr_img), _resnet_features(Xte_img)
    else:
        Xtr_f = Xtr_img.reshape(len(Xtr_img), -1).astype(np.float64) / 255.0
        Xte_f = Xte_img.reshape(len(Xte_img), -1).astype(np.float64) / 255.0

    if ndim and ndim < Xtr_f.shape[1]:
        from sklearn.decomposition import PCA
        p = PCA(n_components=ndim, random_state=seed).fit(Xtr_f)
        Xtr_f, Xte_f = p.transform(Xtr_f), p.transform(Xte_f)
        print(f"PCA-{ndim} retains {p.explained_variance_ratio_.sum():.1%} variance")

    mu, sd = Xtr_f.mean(0), Xtr_f.std(0)
    sd[sd == 0] = 1.0
    return ((Xtr_f - mu) / sd).astype(np.float32), ytr, \
           ((Xte_f - mu) / sd).astype(np.float32), yte, C


def _resnet_features(imgs: np.ndarray) -> np.ndarray:
    import torch, torch.nn as nn
    import torchvision.models as tvm
    import torch.nn.functional as F
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    net = tvm.resnet18(weights=tvm.ResNet18_Weights.IMAGENET1K_V1)
    net.fc = nn.Identity()
    net = net.to(dev).eval()
    mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
    out = []
    with torch.no_grad():
        for i in range(0, len(imgs), 256):
            b = torch.tensor(imgs[i:i + 256]).permute(0, 3, 1, 2).float() / 255.0
            b = F.interpolate(b, size=(224, 224), mode="bilinear", align_corners=False)
            b = ((b - mean) / std).to(dev)
            out.append(net(b).cpu().numpy())
    return np.concatenate(out).astype(np.float64)


def report_support(ytr, parts, C, scenario):
    print(f"\nLABEL SUPPORT ({scenario}) -- the boundary condition:")
    for k, p in enumerate(parts):
        cnt = np.bincount(ytr[p], minlength=C)
        print(f"  client {k}: n={len(p):5d}  dominant={100*cnt.max()/len(p):3.0f}%  "
              f"nonzero classes={int((cnt > 0).sum())}/{C}")
    print("  Pima (C=2) had 1-2/2 -> disjoint -> collapse.")
    print("  Digits (C=10) had 3-10/10 -> overlapping -> no collapse.\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-root", default="results_derma")
    ap.add_argument("--seeds", nargs="+", type=int, default=[7, 23, 42, 101, 202])
    ap.add_argument("--rounds", type=int, default=100)
    ap.add_argument("--ndim", type=int, default=128)
    ap.add_argument("--resnet", action="store_true")
    ap.add_argument("--decisive", action="store_true", help="S2 only")
    a = ap.parse_args()

    scen = ["S2"] if a.decisive else SCEN
    Xtr, ytr, Xte, yte, C = load_dermamnist(a.ndim, a.resnet, a.seeds[0])

    combos = list(itertools.product(a.seeds, scen, METHODS))
    print(f"\n{len(combos)} runs queued")
    t0 = time.time()
    shown = False
    for i, (seed, sc, m) in enumerate(combos, 1):
        p = os.path.join(a.out_root, "derma", sc, m, f"seed{seed}.jsonl")
        if os.path.exists(p):
            continue
        parts, _ = partition(ytr, sc, 5, seed)
        ct = make_client_test_indices(yte, parts, ytr, seed=seed)
        if not shown:
            report_support(ytr, parts, C, sc)
            shown = True
        run_np(ConfigNP(dataset="derma", method=m, scenario=sc, seed=seed,
                        rounds=a.rounds, hidden=(128, 64), out_root=a.out_root,
                        eval_every=5, target_acc=70.0),
               Xtr, ytr, Xte, yte, parts, ct, C)
        if i % 10 == 0:
            el = time.time() - t0
            print(f"  {i}/{len(combos)}  {el/60:.0f}m  eta {el/i*(len(combos)-i)/60:.0f}m",
                  flush=True)
    print(f"\nDONE in {(time.time()-t0)/60:.1f} min\n")

    base = 100.0 * np.bincount(yte).max() / len(yte)
    print("=" * 74)
    print(f"DERMAMNIST RESULT (medical, C={C})")
    print("=" * 74)
    print(f"  Majority-class baseline: {base:.1f}% accuracy, "
          f"{100.0/C:.1f}% balanced accuracy")
    print()
    print(f"  {'method':11s} {'acc':>12s} {'bal_acc':>12s} {'macro_F1':>12s} "
          f"{'collapse':>9s} {'sigma_A':>8s}")
    print("  " + "-" * 70)

    learned = {}
    for m in METHODS:
        try:
            c  = aggregate_seeds(a.out_root, "derma", "S2", m, a.seeds, "acc")
            ba = aggregate_seeds(a.out_root, "derma", "S2", m, a.seeds, "balanced_acc")
            f1 = aggregate_seeds(a.out_root, "derma", "S2", m, a.seeds, "macro_f1")
            cf = aggregate_seeds(a.out_root, "derma", "S2", m, a.seeds, "collapse_frac")
            fa = aggregate_seeds(a.out_root, "derma", "S2", m, a.seeds, "fairness")
            flag = "  <-- COLLAPSED" if cf.mean > 0.90 else ""
            print(f"  {m:11s} {c.mean:6.1f}+/-{c.std:4.1f} {ba.mean:6.1f}+/-{ba.std:4.1f} "
                  f"{f1.mean:6.1f}+/-{f1.std:4.1f} {cf.mean:9.2f} {fa.mean:8.1f}{flag}")
            learned[m] = ba.mean
        except Exception:
            print(f"  {m:11s} (incomplete or logged without balanced metrics)")

    print()
    if learned and max(learned.values()) < 100.0 / C + 5:
        print("  *** WARNING: NO METHOD LEARNED ANYTHING ***")
        print(f"  Every balanced accuracy is at or near the {100.0/C:.1f}% chance level.")
        print("  The comparison below is meaningless -- all methods are constant")
        print("  predictors, so they necessarily tie. Fix the setup before reading")
        print("  anything into the result: try --resnet for stronger features, and")
        print("  consider class-weighted loss or more rounds.")
        print()

    for key, label in [("balanced_acc", "balanced accuracy"), ("macro_f1", "macro F1")]:
        try:
            t = paired_test_metric(a.out_root, "derma", "S2", "dcfl", "fedavg",
                                   a.seeds, key)
            print(f"  DC-FL vs FedAvg ({label}): {t['mean_diff']:+.1f} pts, p={t['t_p']:.3f}")
        except Exception:
            pass
    try:
        t = paired_test(a.out_root, "derma", "S2", "dcfl", "fedavg", a.seeds)
        print(f"  DC-FL vs FedAvg (raw accuracy): {t['mean_diff']:+.1f} pts, p={t['t_p']:.3f}")
    except Exception:
        pass
    print()
    print("  Reference: Pima (C=2) -15.8 pts collapse; Digits (C=10) -1.4 pts no collapse.")
    print("  Judge by BALANCED ACCURACY / MACRO F1, not raw accuracy: on this dataset")
    print("  a constant 'melanocytic nevi' predictor already scores "
          f"{base:.0f}% raw accuracy.")


if __name__ == "__main__":
    main()
