import sys, os, time, itertools
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prep_digits import load
from dcfl.partition import partition
from dcfl.datasets import make_client_test_indices
from dcfl.run_numpy import ConfigNP, run_np, METHODS
OUT="results_digits"; SEEDS=[7,23,42,101,202]; SCEN=["IID","S1","S2","S3","S4"]
combos=list(itertools.product(SEEDS,SCEN,METHODS)); t0=time.time()
print(f"{len(combos)} runs", flush=True)
for i,(seed,sc,m) in enumerate(combos,1):
    p=os.path.join(OUT,"digits",sc,m,f"seed{seed}.jsonl")
    if os.path.exists(p): continue
    Xtr,ytr,Xte,yte=load(seed=seed)
    parts,_=partition(ytr,sc,5,seed)
    ct=make_client_test_indices(yte,parts,ytr,seed=seed)
    run_np(ConfigNP(dataset="digits",method=m,scenario=sc,seed=seed,rounds=100,
                    hidden=(128,64),out_root=OUT,eval_every=5,target_acc=85.0),
           Xtr,ytr,Xte,yte,parts,ct,10)
    if i%25==0: print(f"  {i}/{len(combos)} {time.time()-t0:.0f}s", flush=True)
print(f"DONE {time.time()-t0:.0f}s")
