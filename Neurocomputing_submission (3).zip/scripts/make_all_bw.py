"""Regenerate every figure in greyscale, plus two new diagrams. Reads only logs."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from bwstyle import plt, GREY, LS, MK, barfill
from dcfl.analyze import aggregate_seeds, load_run, final_accuracy, PRETTY
PRETTY['dcfl_vw']='DC-FL (vol)'
SD=[7,23,42,101,202]; OUT="figs_bw"; os.makedirs(OUT,exist_ok=True)

def save(fig,name):
    fig.savefig(f"{OUT}/{name}.pdf",bbox_inches="tight")
    fig.savefig(f"{OUT}/{name}.png",dpi=600,bbox_inches="tight"); plt.close(fig)
    print("wrote",name)

# ---------- 1. convergence ----------
M=['fedavg','scaffold','ifca','cfl','dcfl']
fig,ax=plt.subplots(figsize=(3.4,2.5))
for m in M:
    cur=[]
    for s in SD:
        r=load_run('results_pima','pima','S2',m,s)
        cur.append([x['global_acc'] for x in r if 'global_acc' in x])
    n=min(len(c) for c in cur); mat=np.vstack([c[:n] for c in cur])
    rounds=[x['round'] for x in load_run('results_pima','pima','S2',m,SD[0]) if 'global_acc' in x][:n]
    mu=mat.mean(0)
    ax.plot(rounds,mu,label=PRETTY[m],color=GREY[m],linestyle=LS[m],
            linewidth=2.0 if m=='dcfl' else 1.1,
            marker=MK[m],markevery=max(1,n//8),markersize=3.2,markerfacecolor='white')
    if mat.shape[0]>1:
        ax.fill_between(rounds,mu-mat.std(0,ddof=1),mu+mat.std(0,ddof=1),
                        color='0.75',alpha=0.30,linewidth=0)
ax.set_xlabel("Communication rounds"); ax.set_ylabel("Global test accuracy (%)")
ax.set_title("Convergence under severe label skew (S2), Pima",fontsize=8.4)
ax.grid(True,lw=0.4,alpha=0.4,color='0.8'); ax.set_axisbelow(True)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
ax.legend(loc="lower right",ncol=2,frameon=False,handlelength=3.0,columnspacing=1.0)
save(fig,"fig_convergence_s2")

# ---------- 2. fairness ----------
SC=['S1','S2','S4']
fig,ax=plt.subplots(figsize=(3.4,2.7))
x=np.arange(len(M)); w=0.8/len(SC)
for i,sc in enumerate(SC):
    mu=[aggregate_seeds('results_pima','pima',sc,m,SD,'fairness').mean for m in M]
    sd=[aggregate_seeds('results_pima','pima',sc,m,SD,'fairness').std  for m in M]
    ax.bar(x+(i-(len(SC)-1)/2)*w,mu,w,yerr=sd,capsize=2.0,label=sc,
           error_kw=dict(elinewidth=0.7,capthick=0.7,ecolor='black'),**barfill(i))
ax.set_xticks(x); ax.set_xticklabels([PRETTY[m] for m in M],rotation=20,ha="right")
ax.set_ylabel(r"Fairness index $\sigma_A$")
ax.set_title("Inter-institution disparity (lower is fairer)",fontsize=8.4)
ax.grid(True,axis='y',lw=0.4,alpha=0.4,color='0.8'); ax.set_axisbelow(True)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
ax.legend(frameon=False,ncol=3,fontsize=7,loc='upper left',bbox_to_anchor=(-0.02,1.15))
save(fig,"fig_fairness")

# ---------- 3. label support ----------
from dcfl.partition import partition
from prep_pima import load as lp
from prep_digits import load as ld
def sup(loader,C):
    out=[]
    for s in SD:
        _,ytr,_,_=loader(seed=s)
        for p in partition(ytr,'S2',5,s)[0]:
            out.append((np.bincount(ytr[p],minlength=C)>0).sum()/C)
    return np.array(out)
data=[sup(lp,2),np.array([3,4,3,1,7])/7.0,sup(ld,10)]
labs=["Pima\n$C=2$","DermaMNIST\n$C=7$","Digits\n$C=10$"]
fig,ax=plt.subplots(figsize=(3.4,2.4))
bp=ax.boxplot(data,tick_labels=labs,widths=0.5,patch_artist=True,
              medianprops=dict(color='black',linewidth=1.3),
              boxprops=dict(facecolor='white',edgecolor='black',linewidth=0.8),
              whiskerprops=dict(color='black',linewidth=0.8),
              capprops=dict(color='black',linewidth=0.8),
              flierprops=dict(marker='o',markersize=3,markerfacecolor='white',markeredgecolor='black'))
for i,d in enumerate(data,1):
    ax.scatter(np.random.default_rng(0).normal(i,0.055,len(d)),d,s=9,
               facecolor='white',edgecolor='black',linewidth=0.6,zorder=3)
ax.axhline(0.5,color='black',ls=(0,(4,2)),lw=0.9)
ax.text(3.46,0.53,"half the\nlabel space",fontsize=6.2,ha='right')
ax.set_ylabel("Fraction of classes held per client"); ax.set_ylim(0,1.06)
ax.set_title("Label support under severe skew (S2)",fontsize=8.4)
ax.grid(True,axis='y',lw=0.4,alpha=0.4,color='0.8'); ax.set_axisbelow(True)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
save(fig,"fig_support")

# ---------- 4. NEW: per-seed evidence (the seed-101 outlier) ----------
fig,ax=plt.subplots(figsize=(3.4,2.4))
for j,m in enumerate(['fedavg','dcfl']):
    v=[final_accuracy(load_run('results_digits','digits','S4',m,s)) for s in SD]
    ax.scatter(range(len(SD)),v,s=44,marker='o' if m=='fedavg' else 's',
               facecolor='white' if m=='fedavg' else 'black',
               edgecolor='black',linewidth=1.0,zorder=3,label=PRETTY[m])
sup101=[]
_,ytr101,_,_=ld(seed=101)
for p in partition(ytr101,'S4',5,101)[0]:
    sup101.append(int((np.bincount(ytr101[p],minlength=10)>0).sum()))
ax.annotate(f"seed 101:\none client holds\n1 of 10 classes",
            xy=(3,11.9),xytext=(1.25,34),fontsize=6.4,ha='left',
            arrowprops=dict(arrowstyle='->',lw=0.8,color='black'))
ax.set_xticks(range(len(SD))); ax.set_xticklabels([f"seed {s}" for s in SD],fontsize=7)
ax.set_ylabel("Final accuracy (%)")
ax.set_title("Per-seed outcomes, Digits S4",fontsize=8.4)
ax.grid(True,axis='y',lw=0.4,alpha=0.4,color='0.8'); ax.set_axisbelow(True)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
ax.legend(frameon=False,loc='lower left',fontsize=7)
save(fig,"fig_perseed")

# ---------- 5. NEW: cross-dataset effect size ----------
fig,ax=plt.subplots(figsize=(3.4,2.3))
names=["Pima\n$C=2$","DermaMNIST\n$C=7$","Digits\n$C=10$"]
diff=[-15.8,-2.5,-1.4]; err=[7.4,3.1,2.4]
y=np.arange(len(names))
ax.barh(y,diff,xerr=err,height=0.5,capsize=2.5,
        error_kw=dict(elinewidth=0.7,capthick=0.7,ecolor='black'),
        facecolor='white',edgecolor='black',hatch='///',linewidth=0.9)
ax.axvline(0,color='black',lw=1.0)
ax.set_yticks(y); ax.set_yticklabels(names,fontsize=7.5)
ax.set_xlabel("DC-FL minus FedAvg (percentage points)")
ax.set_title("Effect of demographic clustering by class count",fontsize=8.4)
ax.grid(True,axis='x',lw=0.4,alpha=0.4,color='0.8'); ax.set_axisbelow(True)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
ax.text(-15.5,-0.55,"disjoint support",fontsize=6.3,ha='left',style='italic')
save(fig,"fig_effectsize")
print("done")
