"""Colour versions of the new diagrams + three additional figures. Reads logs only."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
for f in fm.findSystemFonts():
    if "LiberationSerif" in f: fm.fontManager.addfont(f)
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],
 "font.size":9,"axes.titlesize":9,"axes.labelsize":9,"xtick.labelsize":8,
 "ytick.labelsize":8,"legend.fontsize":7.5,"axes.linewidth":0.8,
 "pdf.fonttype":42,"savefig.dpi":600})
from dcfl.analyze import aggregate_seeds, load_run, final_accuracy, PRETTY
from dcfl.partition import partition
from prep_pima import load as lp
from prep_digits import load as ld
PRETTY['dcfl_vw']='DC-FL (vol)'
SD=[7,23,42,101,202]; OUT="figs"
def save(f,n):
    f.savefig(f"{OUT}/{n}.pdf",bbox_inches="tight"); f.savefig(f"{OUT}/{n}.png",dpi=600,bbox_inches="tight")
    plt.close(f); print("wrote",n)

# ---- per-seed (colour) ----
fig,ax=plt.subplots(figsize=(3.45,2.4))
for m,c,mk in [('fedavg','#1f77b4','o'),('dcfl','#d62728','s')]:
    v=[final_accuracy(load_run('results_digits','digits','S4',m,s)) for s in SD]
    ax.scatter(range(len(SD)),v,s=48,marker=mk,color=c,edgecolor='black',lw=0.7,zorder=3,label=PRETTY[m])
ax.annotate("seed 101:\none client holds\n1 of 10 classes",xy=(3,11.9),xytext=(1.2,34),
            fontsize=6.4,arrowprops=dict(arrowstyle='->',lw=0.9,color='#d62728'),color='#d62728')
ax.set_xticks(range(len(SD))); ax.set_xticklabels([f"seed {s}" for s in SD],fontsize=7)
ax.set_ylabel("Final accuracy (%)"); ax.set_title("Per-seed outcomes, Digits S4",fontsize=8.5)
ax.grid(True,axis='y',lw=0.4,alpha=0.4); ax.set_axisbelow(True)
for sp in("top","right"): ax.spines[sp].set_visible(False)
ax.legend(frameon=False,loc='lower left',fontsize=7); save(fig,"fig_perseed")

# ---- effect size (colour) ----
fig,ax=plt.subplots(figsize=(3.45,2.3))
names=["Pima\n$C=2$","DermaMNIST\n$C=7$","Digits\n$C=10$"]; diff=[-15.8,-2.5,-1.4]; err=[7.4,3.1,2.4]
cols=['#d62728','#ff7f0e','#2ca02c']; y=np.arange(3)
ax.barh(y,diff,xerr=err,height=0.5,capsize=2.5,color=cols,edgecolor='black',lw=0.8,
        error_kw=dict(elinewidth=0.7,capthick=0.7))
ax.axvline(0,color='black',lw=1.0); ax.set_yticks(y); ax.set_yticklabels(names,fontsize=7.5)
ax.set_xlabel("DC-FL minus FedAvg (percentage points)")
ax.set_title("Effect of demographic clustering by class count",fontsize=8.5)
ax.grid(True,axis='x',lw=0.4,alpha=0.4); ax.set_axisbelow(True)
for sp in("top","right"): ax.spines[sp].set_visible(False)
ax.text(-15.3,-0.52,"disjoint support",fontsize=6.3,style='italic',color='#d62728')
save(fig,"fig_effectsize")

# ---- mechanism schematic (colour) ----
fig,axes=plt.subplots(1,2,figsize=(6.8,2.5))
for ax,(t,sup,out,col) in zip(axes,[
 ("(a) Disjoint support: collapse",[[1,0,0,0],[1,0,0,0],[0,0,1,1]],
  "cluster models become\nconstant predictors;\naveraging is meaningless","#d62728"),
 ("(b) Overlapping support: no collapse",[[1,1,1,0],[1,1,0,1],[0,1,1,1]],
  "cluster models remain\ncompetent classifiers;\naveraging is meaningful","#2ca02c")]):
    ax.set_xlim(0,10); ax.set_ylim(0,6.4); ax.axis('off')
    ax.text(5,6.0,t,ha='center',fontsize=7.8,weight='bold',color=col)
    for r,row in enumerate(sup):
        ax.text(0.3,4.6-r*1.25,f"$H_{r+1}$",fontsize=6.6,va='center')
        for c,v in enumerate(row):
            ax.add_patch(plt.Rectangle((1.1+c*0.62,4.28-r*1.25),0.52,0.62,
                facecolor=col if v else 'white',alpha=0.85 if v else 1,
                edgecolor='black',lw=0.7))
    ax.text(1.1+2*0.62,5.25,"classes",fontsize=6.0,ha='center',style='italic')
    ax.annotate("",xy=(6.4,3.6),xytext=(4.25,3.6),arrowprops=dict(arrowstyle='-|>',lw=1.1,color=col))
    ax.text(6.7,3.6,out,fontsize=6.3,va='center')
fig.tight_layout(pad=0.4); save(fig,"fig_mechanism")

# ---- NEW: accuracy heatmap across methods x scenarios ----
M=['local_only','fedavg','fedprox','fednova','scaffold','edge_avg','ifca','cfl','dcfl','dcfl_vw']
S=['IID','S1','S2','S3','S4']
mat=np.array([[aggregate_seeds('results_pima','pima',s,m,SD,'acc').mean for s in S] for m in M])
fig,ax=plt.subplots(figsize=(3.45,3.2))
im=ax.imshow(mat,cmap='RdYlGn',aspect='auto',vmin=45,vmax=75)
ax.set_xticks(range(len(S))); ax.set_xticklabels(S)
ax.set_yticks(range(len(M))); ax.set_yticklabels([PRETTY[m] for m in M],fontsize=7)
for i in range(len(M)):
    for j in range(len(S)):
        ax.text(j,i,f"{mat[i,j]:.0f}",ha='center',va='center',fontsize=6.2,
                color='black')
ax.set_title("Accuracy (%) on Pima across scenarios",fontsize=8.5)
fig.colorbar(im,ax=ax,shrink=0.8,label="accuracy (%)")
fig.tight_layout(pad=0.3); save(fig,"fig_heatmap")

# ---- NEW: variance comparison ----
fig,ax=plt.subplots(figsize=(3.45,2.4))
MM=['fedavg','fedprox','fednova','scaffold','ifca','cfl','dcfl','dcfl_vw']
sds=[aggregate_seeds('results_pima','pima','S2',m,SD,'acc').std for m in MM]
cols=['#d62728' if m.startswith('dcfl') else '#1f77b4' for m in MM]
ax.bar(range(len(MM)),sds,0.6,color=cols,edgecolor='black',lw=0.7)
ax.set_xticks(range(len(MM))); ax.set_xticklabels([PRETTY[m] for m in MM],rotation=30,ha='right',fontsize=7)
ax.set_ylabel("Std. dev. of accuracy across seeds")
ax.set_title("Run-to-run instability under S2 (Pima)",fontsize=8.5)
ax.grid(True,axis='y',lw=0.4,alpha=0.4); ax.set_axisbelow(True)
for sp in("top","right"): ax.spines[sp].set_visible(False)
save(fig,"fig_variance")
