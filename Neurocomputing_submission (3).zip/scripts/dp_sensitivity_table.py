"""Reproduces Table 2: cluster recovery under scalar vs per-component DP sensitivity."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from dcfl.algorithms import distribution_signature, cluster_by_signature

rng = np.random.default_rng(0); NC = 4
clients = []
for dom, frac in [(0,.80),(0,.75),(1,.72),(3,.69),(1,.55)]:
    n = 3000
    y = rng.integers(0, NC, size=n)
    y[rng.random(n) < frac] = dom
    clients.append(y)
TRUTH = [0,0,1,1,2]

def agreement(lab):
    return sum((lab[i]==lab[j])==(TRUTH[i]==TRUTH[j])
               for i in range(5) for j in range(i+1,5)) / 10

print("eps    scalar(ds=1)  per-component")
for eps in [10.0, 5.0, 1.0, 0.5, 0.1]:
    sc, pc = [], []
    for t in range(20):
        s1 = [distribution_signature(y,None,None,NC,epsilon=eps,sensitivity=1.0,
              rng=np.random.default_rng(1000*t+i)) for i,y in enumerate(clients)]
        s2 = [distribution_signature(y,None,None,NC,epsilon=eps,
              rng=np.random.default_rng(1000*t+i)) for i,y in enumerate(clients)]
        sc.append(agreement(cluster_by_signature(np.vstack(s1))))
        pc.append(agreement(cluster_by_signature(np.vstack(s2))))
    print("%5.1f  %.2f          %.2f" % (eps, np.mean(sc), np.mean(pc)))
