"""Greyscale, print-safe figure style for Elsevier. No colour, no fills."""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
for f in fm.findSystemFonts():
    if "LiberationSerif" in f: fm.fontManager.addfont(f)
plt.rcParams.update({
    "font.family":"serif","font.serif":["Liberation Serif","Times New Roman"],
    "font.size":9,"axes.titlesize":9,"axes.labelsize":9,
    "xtick.labelsize":8,"ytick.labelsize":8,"legend.fontsize":7.5,
    "axes.linewidth":0.8,"lines.linewidth":1.3,
    "pdf.fonttype":42,"ps.fonttype":42,"savefig.dpi":600,
    "figure.facecolor":"white","axes.facecolor":"white","savefig.facecolor":"white",
})
# distinguishable without colour: linestyle + marker + greyscale
GREY = {"local_only":"0.60","fedavg":"0.0","fedprox":"0.35","fednova":"0.50",
        "scaffold":"0.20","edge_avg":"0.55","ifca":"0.40","cfl":"0.30","dcfl":"0.0",
        "dcfl_vw":"0.45"}
LS = {"local_only":(0,(1,1.5)),"fedavg":(0,(6,2)),"fedprox":(0,(3,1.5)),
      "fednova":(0,(4,1,1,1)),"scaffold":(0,(1,1)),"edge_avg":(0,(5,1,1,1,1,1)),
      "ifca":(0,(2,1)),"cfl":(0,(7,1.5,1,1.5)),"dcfl":"solid","dcfl_vw":(0,(3,1,3,1,1,1))}
MK = {"local_only":"x","fedavg":"o","fedprox":"^","fednova":"s","scaffold":"v",
      "edge_avg":"D","ifca":"P","cfl":"*","dcfl":None,"dcfl_vw":"h"}
HATCH = ["", "///", "...", "xxx", "\\\\\\", "|||"]
def barfill(i):
    """White bars distinguished by hatch pattern only."""
    return dict(facecolor="white", edgecolor="black", hatch=HATCH[i % len(HATCH)], linewidth=0.8)
