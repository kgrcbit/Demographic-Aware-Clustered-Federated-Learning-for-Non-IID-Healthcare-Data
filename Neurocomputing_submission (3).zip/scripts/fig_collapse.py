"""Figure: cluster models collapse to single-class predictors under severe skew."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
for f in fm.findSystemFonts():
    if "LiberationSerif" in f: fm.fontManager.addfont(f)
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],
    "font.size":9,"axes.labelsize":9,"xtick.labelsize":8,"ytick.labelsize":8,
    "legend.fontsize":7.5,"pdf.fonttype":42,"savefig.dpi":600})
from prep_pima import load
from dcfl.partition import partition
from dcfl.backend_numpy import init_mlp, local_train, weighted_sum, forward, evaluate

Xtr,ytr,Xte,yte = load(seed=7)
parts,_ = partition(ytr,'S2',5,7)
gp = init_mlp(8,(64,32,16),2,np.random.default_rng(7))
cl = {0:[0,1,4], 1:[2,3]}
models={}
for c,mem in cl.items():
    p=gp
    for rnd in range(50):
        ps=[local_train(p,Xtr[parts[i]],ytr[parts[i]],lr=0.01,local_epochs=5,
             rng=np.random.default_rng(rnd*10+i)).params for i in mem]
        p=weighted_sum(ps,[len(parts[i]) for i in mem])
    models[c]=p
merged = weighted_sum([models[0],models[1]],[3,2])

names, frac0, accs = [], [], []
for c in [0,1]:
    lg,_=forward(models[c],Xte)
    names.append(f"Cluster {c+1}\nmodel"); frac0.append(100*np.mean(lg.argmax(1)==0))
    accs.append(evaluate(models[c],Xte,yte)[0])
lg,_=forward(merged,Xte)
names.append("Merged\nglobal"); frac0.append(100*np.mean(lg.argmax(1)==0)); accs.append(evaluate(merged,Xte,yte)[0])

fig,(ax1,ax2)=plt.subplots(1,2,figsize=(6.8,2.6))
x=np.arange(3)
ax1.bar(x,frac0,0.55,color=["#1f77b4","#2ca02c","#555555"],edgecolor="black",linewidth=0.6)
ax1.axhline(100*np.mean(yte==0),color="#c00000",ls="--",lw=1.0)
ax1.text(2.45,100*np.mean(yte==0)+3,"test-set\nclass-0 rate",fontsize=6.3,color="#c00000",ha="right")
ax1.set_xticks(x); ax1.set_xticklabels(names); ax1.set_ylim(0,108)
ax1.set_ylabel("Predictions assigned to class 0 (%)")
ax1.set_title("Cluster models collapse to one class",fontsize=8.4)
ax2.bar(x,accs,0.55,color=["#1f77b4","#2ca02c","#555555"],edgecolor="black",linewidth=0.6)
ax2.axhline(100*max(np.mean(yte==0),np.mean(yte==1)),color="#c00000",ls="--",lw=1.0)
ax2.text(2.45,100*max(np.mean(yte==0),np.mean(yte==1))+2,"majority-class\nbaseline",fontsize=6.3,color="#c00000",ha="right")
ax2.set_xticks(x); ax2.set_xticklabels(names); ax2.set_ylim(0,80)
ax2.set_ylabel("Test accuracy (%)")
ax2.set_title("Merging degenerate models in weight space",fontsize=8.4)
for a in (ax1,ax2):
    a.grid(True,axis="y",lw=0.4,alpha=0.4); a.set_axisbelow(True)
    a.spines["top"].set_visible(False); a.spines["right"].set_visible(False)
fig.tight_layout(pad=0.4)
os.makedirs("figs",exist_ok=True)
fig.savefig("figs/fig_collapse.pdf",bbox_inches="tight")
fig.savefig("figs/fig_collapse.png",dpi=600,bbox_inches="tight")
print("wrote figs/fig_collapse.pdf")
