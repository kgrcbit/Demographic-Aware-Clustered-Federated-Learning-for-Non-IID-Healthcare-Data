import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dcfl.partition import partition
from dcfl.datasets import make_client_test_indices

def load(csv='/tmp/diabetes.csv', seed=0, test_frac=0.2):
    raw = np.genfromtxt(csv, delimiter=',', skip_header=1)
    X, y = raw[:, :8], raw[:, 8].astype(int)
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(y))
    nte = int(round(test_frac*len(y)))
    te, tr = idx[:nte], idx[nte:]
    mu, sd = X[tr].mean(0), X[tr].std(0); sd[sd==0]=1
    Xs = (X-mu)/sd
    return Xs[tr], y[tr], Xs[te], y[te]
