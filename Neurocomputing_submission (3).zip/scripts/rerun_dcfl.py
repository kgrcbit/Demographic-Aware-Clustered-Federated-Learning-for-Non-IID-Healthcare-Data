import sys, os, itertools, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prep_pima import load
from dcfl.partition import partition
from dcfl.datasets import make_client_test_indices
from dcfl.run_numpy import ConfigNP, run_np
t0=time.time()
for seed, sc in itertools.product([7,23,42,101,202], ["IID","S1","S2","S3","S4"]):
    p=f"results_pima/pima/{sc}/dcfl/seed{seed}.jsonl"
    if os.path.exists(p): continue
    Xtr,ytr,Xte,yte=load(seed=seed)
    parts,_=partition(ytr,sc,5,seed)
    ct=make_client_test_indices(yte,parts,ytr,seed=seed)
    run_np(ConfigNP(method="dcfl",scenario=sc,seed=seed,rounds=200,
                    out_root="results_pima",eval_every=5,target_acc=75.0),
           Xtr,ytr,Xte,yte,parts,ct,2)
print("done %.0fs"%(time.time()-t0))
