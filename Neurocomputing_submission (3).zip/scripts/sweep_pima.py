import sys, os, time, itertools, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from prep_pima import load
from dcfl.partition import partition
from dcfl.datasets import make_client_test_indices
from dcfl.run_numpy import ConfigNP, run_np, METHODS

SCEN = ["IID","S1","S2","S3","S4"]
SEEDS = [7,23,42,101,202]
OUT = sys.argv[1] if len(sys.argv)>1 else "results_pima"

combos = list(itertools.product(SEEDS, SCEN, METHODS))
print(f"{len(combos)} runs", flush=True)
t_all = time.time()
for i,(seed,sc,m) in enumerate(combos,1):
    p = os.path.join(OUT,"pima",sc,m,f"seed{seed}.jsonl")
    if os.path.exists(p): continue
    Xtr,ytr,Xte,yte = load(seed=seed)
    parts,_ = partition(ytr, sc, 5, seed)
    ct = make_client_test_indices(yte, parts, ytr, seed=seed)
    cfg = ConfigNP(method=m, scenario=sc, seed=seed, rounds=200,
                   out_root=OUT, eval_every=5, target_acc=75.0)
    run_np(cfg, Xtr,ytr,Xte,yte, parts, ct, 2)
    if i % 25 == 0:
        print(f"  {i}/{len(combos)}  elapsed {time.time()-t_all:.0f}s", flush=True)
print(f"DONE in {time.time()-t_all:.0f}s")
