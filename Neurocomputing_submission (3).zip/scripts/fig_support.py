"""Fig: label support per client across the three datasets -- the governing variable."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
for f in fm.findSystemFonts():
    if "LiberationSerif" in f: fm.fontManager.addfont(f)
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],
 "font.size":9,"axes.labelsize":9,"xtick.labelsize":8,"ytick.labelsize":8,
 "legend.fontsize":7.5,"pdf.fonttype":42,"savefig.dpi":600})
from dcfl.partition import partition
from prep_pima import load as load_pima
from prep_digits import load as load_digits

SEEDS=[7,23,42,101,202]
def support(loader,C):
    frac=[]
    for s in SEEDS:
        Xtr,ytr,_,_=loader(seed=s)
        for p in partition(ytr,'S2',5,s)[0]:
            frac.append((np.bincount(ytr[p],minlength=C)>0).sum()/C)
    return np.array(frac)

pima=support(load_pima,2); dig=support(load_digits,10)
# DermaMNIST support measured in the reported run (5 clients, seed 7 shown in text)
derma=np.array([3,4,3,1,7])/7.0

fig,ax=plt.subplots(figsize=(3.45,2.5))
data=[pima,derma,dig]; labels=["Pima\n$C=2$","DermaMNIST\n$C=7$","Digits\n$C=10$"]
bp=ax.boxplot(data,labels=labels,widths=0.55,patch_artist=True,
              medianprops=dict(color="black",linewidth=1.2))
for patch,c in zip(bp['boxes'],["#d62728","#ff7f0e","#2ca02c"]):
    patch.set_facecolor(c); patch.set_alpha(0.45); patch.set_edgecolor("black"); patch.set_linewidth(0.7)
for i,d in enumerate(data,1):
    ax.scatter(np.random.default_rng(0).normal(i,0.05,len(d)),d,s=7,color="black",alpha=0.5,zorder=3)
ax.axhline(0.5,color="#c00000",ls="--",lw=0.9)
ax.text(3.45,0.52,"half the\nlabel space",fontsize=6.2,color="#c00000",ha="right")
ax.set_ylabel("Fraction of classes held per client")
ax.set_ylim(0,1.05)
ax.set_title("Label support under severe skew (S2)",fontsize=8.6)
ax.grid(True,axis="y",lw=0.4,alpha=0.4); ax.set_axisbelow(True)
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
fig.tight_layout(pad=0.4)
os.makedirs("figs",exist_ok=True)
fig.savefig("figs/fig_support.pdf",bbox_inches="tight")
fig.savefig("figs/fig_support.png",dpi=600,bbox_inches="tight")
print("wrote figs/fig_support.pdf")
