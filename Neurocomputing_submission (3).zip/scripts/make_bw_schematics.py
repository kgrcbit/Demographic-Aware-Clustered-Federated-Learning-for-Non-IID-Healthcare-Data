"""Greyscale framework diagram, collapse figure, and a new mechanism schematic."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from bwstyle import plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
OUT="figs_bw"; os.makedirs(OUT,exist_ok=True)
def save(fig,n):
    fig.savefig(f"{OUT}/{n}.pdf",bbox_inches="tight")
    fig.savefig(f"{OUT}/{n}.png",dpi=600,bbox_inches="tight"); plt.close(fig); print("wrote",n)

# ---------- framework (greyscale) ----------
fig,ax=plt.subplots(figsize=(6.5,2.4)); ax.set_xlim(0,100); ax.set_ylim(0,32); ax.axis("off")
def box(x,y,w,h,t,body):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0,rounding_size=1.0",
        lw=0.9,edgecolor='black',facecolor='white',zorder=2))
    ax.text(x+w/2,y+h-2.1,t,ha='center',va='center',fontsize=6.5,weight='bold',zorder=4)
    for i,ln in enumerate(body):
        ax.text(x+w/2,y+h-4.7-i*2.4,ln,ha='center',va='center',fontsize=5.5,zorder=4)
def arr(x0,x1,y,txt=None):
    ax.add_patch(FancyArrowPatch((x0,y),(x1,y),arrowstyle='-|>',mutation_scale=9,lw=1.0,color='black',zorder=3))
    if txt: ax.text((x0+x1)/2,y+1.3,txt,ha='center',fontsize=5.3,style='italic')
W,H,Y=20,17,10
box(1,Y,W,H,"1. Local training",["Institution $k$ trains","$w_k$ on $\\mathcal{D}_k$","$E$ local epochs"])
box(26,Y,W,H,"2. Signature + DP",["class proportions","+ feature statistics","+ Laplace$(\\Delta s/\\epsilon)$","per-component $\\Delta s$"])
box(51,Y,W,H,"3. Clustering",["cosine similarity","agglomerative,","silhouette-selected","every $\\tau$ rounds"])
box(76,Y,W,H,"4. Two-level agg.",["intra: size-weighted","inter: $\\beta_m\\propto|G_m|Q_m$","singleton guard"])
arr(21,26,Y+H/2,"$\\tilde s_k$"); arr(46,51,Y+H/2,"$\\{\\tilde s_k\\}$"); arr(71,76,Y+H/2,"$\\{G_m\\}$")
ax.add_patch(FancyArrowPatch((86,Y),(11,Y),connectionstyle="arc3,rad=0.30",arrowstyle='-|>',
    mutation_scale=9,lw=0.9,color='black',ls=(0,(4,2)),zorder=3))
ax.text(48,1.0,"broadcast $w^{t+1}$ to all institutions",ha='center',fontsize=5.7,style='italic')
ax.text(48,30,"One communication round",ha='center',fontsize=7.2,weight='bold')
save(fig,"fig_framework")

# ---------- NEW: mechanism schematic, disjoint vs overlapping ----------
fig,axes=plt.subplots(1,2,figsize=(6.5,2.5))
for ax,(title,sup,outcome) in zip(axes,[
    ("(a) Disjoint support: collapse",[[1,0,0,0],[1,0,0,0],[0,0,1,1]],
     "cluster models become\nconstant predictors;\naveraging is meaningless"),
    ("(b) Overlapping support: no collapse",[[1,1,1,0],[1,1,0,1],[0,1,1,1]],
     "cluster models remain\ncompetent classifiers;\naveraging is meaningful")]):
    ax.set_xlim(0,10); ax.set_ylim(0,6.4); ax.axis('off')
    ax.text(5,6.0,title,ha='center',fontsize=7.6,weight='bold')
    for r,row in enumerate(sup):
        ax.text(0.35,4.6-r*1.25,f"$H_{r+1}$",fontsize=6.5,va='center')
        for c,v in enumerate(row):
            ax.add_patch(plt.Rectangle((1.1+c*0.62,4.28-r*1.25),0.52,0.62,
                facecolor='black' if v else 'white',edgecolor='black',lw=0.7))
    ax.text(1.1+2*0.62,5.25,"classes",fontsize=6.0,ha='center',style='italic')
    ax.annotate("",xy=(6.4,3.6),xytext=(4.2,3.6),
                arrowprops=dict(arrowstyle='-|>',lw=1.0,color='black'))
    ax.text(6.7,3.6,outcome,fontsize=6.2,va='center',ha='left')
fig.tight_layout(pad=0.4)
save(fig,"fig_mechanism")

# ---------- collapse (greyscale, from real computation) ----------
from prep_pima import load
from dcfl.partition import partition
from dcfl.backend_numpy import init_mlp, local_train, weighted_sum, forward, evaluate
Xtr,ytr,Xte,yte=load(seed=7); parts,_=partition(ytr,'S2',5,7)
gp=init_mlp(8,(64,32,16),2,np.random.default_rng(7)); cl={0:[0,1,4],1:[2,3]}; models={}
for c,mem in cl.items():
    p=gp
    for rnd in range(50):
        ps=[local_train(p,Xtr[parts[i]],ytr[parts[i]],lr=0.01,local_epochs=5,
            rng=np.random.default_rng(rnd*10+i)).params for i in mem]
        p=weighted_sum(ps,[len(parts[i]) for i in mem])
    models[c]=p
merged=weighted_sum([models[0],models[1]],[3,2])
names,frac0,accs=[],[],[]
for c in [0,1]:
    lg,_=forward(models[c],Xte); names.append(f"Cluster {c+1}\nmodel")
    frac0.append(100*np.mean(lg.argmax(1)==0)); accs.append(evaluate(models[c],Xte,yte)[0])
lg,_=forward(merged,Xte); names.append("Merged\nglobal")
frac0.append(100*np.mean(lg.argmax(1)==0)); accs.append(evaluate(merged,Xte,yte)[0])
fig,(a1,a2)=plt.subplots(1,2,figsize=(6.5,2.5)); x=np.arange(3)
for ax,vals,ylab,ttl,ref,reflab in [
 (a1,frac0,"Predictions assigned to class 0 (%)","Cluster models collapse to one class",
  100*np.mean(yte==0),"test-set class-0 rate"),
 (a2,accs,"Test accuracy (%)","Merging degenerate models in weight space",
  100*max(np.mean(yte==0),np.mean(yte==1)),"majority-class baseline")]:
    for i,v in enumerate(vals):
        ax.bar(i,v,0.5,facecolor='white',edgecolor='black',lw=0.9,
               hatch=['','///','...'][i])
    ax.axhline(ref,color='black',ls=(0,(4,2)),lw=0.9)
    ax.text(2.48,ref+2,reflab,fontsize=6.2,ha='right')
    ax.set_xticks(x); ax.set_xticklabels(names,fontsize=7)
    ax.set_ylabel(ylab); ax.set_title(ttl,fontsize=8.0)
    ax.grid(True,axis='y',lw=0.4,alpha=0.4,color='0.8'); ax.set_axisbelow(True)
    for sp in ("top","right"): ax.spines[sp].set_visible(False)
a1.set_ylim(0,110); a2.set_ylim(0,80)
fig.tight_layout(pad=0.4)
save(fig,"fig_collapse")
