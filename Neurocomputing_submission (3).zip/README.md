# Neurocomputing submission

elsarticle [preprint,12pt]. Build: pdflatex x2. 26 pages.
All 8 figures are GREYSCALE, print-safe: distinguished by line style, marker
and hatch pattern only, no colour, white backgrounds throughout.
Regenerate with: python scripts/make_all_bw.py && python scripts/make_bw_schematics.py

Zero APC: Neurocomputing is hybrid. Decline open access at acceptance.

Title alternatives (edit \title{} near the top):
 current  Demographic clustering in federated learning helps only when cluster
          label supports overlap: evidence from three datasets
 B  On the limits of demographic clustering for federated learning under
    severe label skew
 C  When clustered federated learning fails: the role of label support overlap
 D  Label support overlap determines the efficacy of clustered aggregation in
    federated learning

Before submitting:
 1. Highlights file, 3 to 5 bullets, 85 chars max each
 2. Declaration of Competing Interest, separate file
 3. CRediT author statement, revise the placeholder
 4. Data availability statement, insert repository URL
 5. DermaMNIST numbers are transcribed from console output, not computed from
    logs. Regenerate from results_derma/ first.
