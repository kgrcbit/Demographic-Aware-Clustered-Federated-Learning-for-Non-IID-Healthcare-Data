# Neurocomputing upload checklist

Authors: Kommu Gangadhara Rao (corresponding, CBIT IT), M. Ramchander
(CBIT MCA), V. Subba Ramaiah (MGIT CSE), T. Preetham (CBIT IT)

Repository (in the paper's Data Availability statement):
https://github.com/kgrcbit/Demographic-Aware-Clustered-Federated-Learning-for-Non-IID-Healthcare-Data

## Upload these
  paper_neurocomputing.tex + the 10 fig_*.pdf   -> Manuscript
  submission_files/highlights.txt               -> Highlights
  submission_files/declaration_of_interest.txt  -> Declaration of Interest
  submission_files/cover_letter.txt             -> Cover Letter

## Push to the repo before submitting
  dcfl/ scripts/ requirements.txt diabetes.csv
  results_pima/    (250 run logs, included here)
  results_digits/  (250 run logs, included here)
  results_derma/   (50 run logs, NOT here -- from your Colab/Kaggle run)

The Data Availability statement promises reviewers all three log sets.
results_derma is the only one missing. The DermaMNIST row of the cross-dataset
table was transcribed from console output; regenerate it from those logs.

## Zero APC
Neurocomputing is hybrid. Decline open access at acceptance.

## Verified
  28 pages, 0 compile errors, 0 undefined references, 0 TODO markers
  10 figures (colour), 6 tables, 5 equations: all labelled and referenced
  49 references: all cited, none orphaned
  Pima and Digits numbers: checked cell by cell against run logs
  Worst overfull box 3.4pt (cosmetic)
