# Neurocomputing upload checklist

## Files to upload
  paper_neurocomputing.tex + the 10 fig_*.pdf      -> Manuscript
  submission_files/highlights.txt                  -> Highlights
  submission_files/declaration_of_interest.txt     -> Declaration of Interest
  submission_files/cover_letter.txt                -> Cover Letter
  results_pima/ results_digits/ dcfl/ scripts/     -> Supplementary / repository

## Two things you must do first

1. REPOSITORY URL. Search the .tex for
       ADD-REPOSITORY-URL-HERE   and   ADD-COMMIT-HASH
   Create the public repo (code + results_pima + results_digits + results_derma)
   and paste the URL and commit hash. The Data Availability statement promises
   reviewers these logs.

2. DERMAMNIST LOGS. The DermaMNIST row of Table "Across class counts" was
   produced on Colab/Kaggle and those logs are not in this package. Put
   results_derma/ into the repository before you submit, and regenerate the row
   from the logs rather than from console output.

## Zero APC
Neurocomputing is hybrid. Decline open access at acceptance and there is no
charge.

## Status
  Compile: clean, 28 pages, 0 errors, 0 undefined references
  Figures: 10, all colour, all referenced
  Tables: 6, all referenced. Equations: 5, all referenced
  References: 49, all cited, none orphaned
  Pima and Digits numbers: verified cell by cell against run logs
