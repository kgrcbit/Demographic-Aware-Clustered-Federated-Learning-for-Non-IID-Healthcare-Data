"""
DC-FL architecture figure: layered, with real per-client label distributions,
the signature pipeline, the similarity matrix that drives clustering, and the
two-level aggregation. Client distributions are read from an actual S2
partition so the figure is not a cartoon.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
for f in fm.findSystemFonts():
    if "LiberationSerif" in f: fm.fontManager.addfont(f)
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],
    "pdf.fonttype":42,"savefig.dpi":600})

from dcfl.partition import partition
from prep_digits import load as ld

# real S2 partition on the 10-class benchmark, for the client histograms
_, ytr, _, _ = ld(seed=7)
parts, _ = partition(ytr, "S2", 5, 7)
C = 10
dists = [np.bincount(ytr[p], minlength=C) / len(p) for p in parts]
CLUSTER = [0, 0, 1, 1, 1]          # illustrative grouping
CCOL = ["#1f77b4", "#2ca02c"]

fig, ax = plt.subplots(figsize=(7.1, 5.4))
ax.set_xlim(0, 100); ax.set_ylim(0, 78); ax.axis("off")

def band(y, h, label, fc):
    ax.add_patch(FancyBboxPatch((9.0, y), 90.0, h,
        boxstyle="round,pad=0,rounding_size=1.0", linewidth=0,
        facecolor=fc, zorder=0))
    ax.text(6.2, y + h/2, label, fontsize=6.3, weight="bold", color="#555",
            rotation=90, ha="center", va="center", zorder=1)

def box(x, y, w, h, lines, ec, fc="white", fs=5.6, bold_first=False, z=3):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
        boxstyle="round,pad=0,rounding_size=0.9", linewidth=1.0,
        edgecolor=ec, facecolor=fc, zorder=z))
    n = len(lines); lh = h / (n + 0.6)
    for i, ln in enumerate(lines):
        ax.text(x + w/2, y + h - lh*(i + 0.8), ln, ha="center", va="center",
                fontsize=fs, zorder=z+1,
                weight="bold" if (bold_first and i == 0) else "normal")

def arrow(x0, y0, x1, y1, color="#333", ls="-", lw=1.1, rad=0.0, txt=None,
          dx=0.0, dy=1.1, fs=5.4):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>",
        mutation_scale=9, linewidth=lw, color=color, linestyle=ls,
        connectionstyle=f"arc3,rad={rad}", zorder=4))
    if txt:
        ax.text((x0+x1)/2 + dx, max(y0, y1) + dy, txt, ha="center",
                fontsize=fs, style="italic", color=color, zorder=5)

# ============================ LAYER 1: institutions ========================
band(58.5, 19.0, "INSTITUTIONS", "#eef3f8")
xs = [11.5 + i*17.4 for i in range(5)]
for i, x in enumerate(xs):
    c = CCOL[CLUSTER[i]]
    box(x, 61.0, 14.6, 13.6, [], c, "white")
    ax.text(x+7.3, 73.0, f"$H_{i+1}$   $n_k$={len(parts[i])}", ha="center",
            fontsize=5.9, weight="bold", color=c, zorder=5)
    # inline label histogram: the actual class distribution
    bx, by, bw, bh = x+1.4, 63.2, 11.8, 6.4
    ax.add_patch(Rectangle((bx, by), bw, bh, facecolor="#fafafa",
                           edgecolor="#bbb", linewidth=0.5, zorder=4))
    w = bw / C
    for k in range(C):
        ax.add_patch(Rectangle((bx + k*w, by), w*0.86, max(0.12, dists[i][k]*bh),
                               facecolor=c, edgecolor="none", alpha=0.85, zorder=5))
    ax.text(x+7.3, 62.0, "local label distribution", ha="center", fontsize=4.5,
            color="#666", zorder=5)
    ax.text(x+7.3, 70.6, "train $w_k$  ($E$ epochs)", ha="center", fontsize=4.9, zorder=5)

# ============================ LAYER 2: privacy =============================
band(45.5, 11.0, "PRIVACY (on-device)", "#fbf2e6")
for i, x in enumerate(xs):
    box(x, 46.6, 14.6, 8.4,
        ["Signature $s_k$",
         "$[\\hat P_k(y_c);\\ \\mu_k^j,\\sigma_k^j]$",
         "$+\\,\\mathrm{Lap}(\\Delta s/\\epsilon)$",
         "$\\Delta s$ per component"],
        "#c07a1e", "white", fs=5.0, bold_first=True)
    arrow(x+7.3, 61.0, x+7.3, 55.0, color="#3b6ea5", lw=0.9)
ax.text(56, 42.9, "only $\\tilde s_k$ (a few hundred bytes) leaves the institution",
        ha="center", fontsize=5.3, style="italic", color="#8a6410")

# ============================ LAYER 3: server ==============================
band(20.5, 22.0, "AGGREGATION SERVER", "#f3eefa")
for i, x in enumerate(xs):
    arrow(x+7.3, 46.6, min(max(x+7.3, 28), 78), 40.9, color="#c07a1e", lw=0.9, rad=0.0)


# similarity matrix
mx, my, ms = 12.5, 24.5, 12.4
ax.text(mx+ms/2, 38.6, "1. Pairwise similarity", ha="center", fontsize=5.8, weight="bold")
sim = np.zeros((5,5))
for a in range(5):
    for b in range(5):
        u, v = dists[a], dists[b]
        sim[a,b] = float(u@v/(np.linalg.norm(u)*np.linalg.norm(v)+1e-12))
cell = ms/5
for a in range(5):
    for b in range(5):
        ax.add_patch(Rectangle((mx+b*cell, my+ms-(a+1)*cell), cell, cell,
            facecolor=plt.cm.Purples(0.15+0.75*sim[a,b]), edgecolor="white",
            linewidth=0.5, zorder=3))
ax.text(mx+ms/2, my-1.9, "$\\mathrm{sim}(H_i,H_j)=\\dfrac{\\tilde s_i\\cdot\\tilde s_j}"
        "{\\|\\tilde s_i\\|\\|\\tilde s_j\\|}$", ha="center", fontsize=5.4, zorder=5)

arrow(mx+ms+0.8, my+ms/2, mx+ms+4.6, my+ms/2, color="#5a3b8a")

# clustering
cx = mx+ms+5.2
ax.text(cx+11, 38.6, "2. Clustering", ha="center", fontsize=5.8, weight="bold")
box(cx, 30.2, 22, 6.6, ["Hierarchical agglomerative",
    "cut chosen by silhouette score", "re-run every $\\tau$ rounds"],
    "#5a3b8a", "white", fs=5.0)
box(cx, 23.0, 10.4, 6.0, ["$G_1$", "$H_1,H_2$"], CCOL[0], "white", fs=5.2, bold_first=True)
box(cx+11.6, 23.0, 10.4, 6.0, ["$G_2$", "$H_3,H_4,H_5$"], CCOL[1], "white", fs=5.2, bold_first=True)
arrow(cx+11, 30.2, cx+11, 29.0, color="#5a3b8a", lw=0.9)

arrow(cx+22.4, 29.5, cx+26.4, 29.5, color="#2c8a52")

# aggregation
ax_ = cx+27.0
ax.text(ax_+13, 38.6, "3. Two-level aggregation", ha="center", fontsize=5.8, weight="bold")
box(ax_, 31.4, 26, 5.6,
    ["Stage 1  intra-cluster (size-weighted)",
     "$w_{G_m}^{t+1}=\\sum_{k\\in G_m}\\frac{n_k}{\\sum_{j\\in G_m}n_j}w_k^{t+1}$"],
    "#2c8a52", "white", fs=5.0, bold_first=True)
box(ax_, 24.2, 26, 5.9,
    ["Stage 2  inter-cluster (quality-weighted)",
     "$w^{t+1}=\\sum_m \\beta_m w^{t+1}_{G_m}$,",
     "$\\beta_m\\propto|G_m|Q_m$,  singleton guard"],
    "#2c8a52", "white", fs=5.0, bold_first=True)
arrow(ax_+13, 31.4, ax_+13, 30.1, color="#2c8a52", lw=0.9)

# ============================ global model + broadcast =====================
gx, gy, gr = 50, 12.0, 5.1
ax.add_patch(plt.Circle((gx, gy), gr, facecolor="#e3f3ea", edgecolor="#2c8a52",
                        linewidth=1.3, zorder=4))
ax.text(gx, gy+1.0, "Global", ha="center", fontsize=6.4, weight="bold", color="#1a4d2e", zorder=5)
ax.text(gx, gy-1.4, "$w^{t+1}$", ha="center", fontsize=6.4, weight="bold", color="#1a4d2e", zorder=5)
arrow(ax_+13, 24.2, gx+gr*0.75, gy+gr*0.75, color="#2c8a52", rad=0.15)

for xx, yy in [(gx-gr*0.7, gy+gr*0.7)]:
    ax.add_patch(FancyArrowPatch((xx, yy), (2.6, 12.0),
        connectionstyle="arc3,rad=0.20", arrowstyle="-", mutation_scale=9,
        linewidth=1.0, color="#c0392b", linestyle=(0,(4,2)), zorder=4))
ax.add_patch(FancyArrowPatch((2.6, 12.0), (2.6, 66.0), arrowstyle="-",
    mutation_scale=9, linewidth=1.0, color="#c0392b", linestyle=(0,(4,2)), zorder=4))
ax.add_patch(FancyArrowPatch((2.6, 66.0), (11.5, 67.8), arrowstyle="-|>",
    mutation_scale=9, linewidth=1.0, color="#c0392b", linestyle=(0,(4,2)), zorder=4))
ax.text(1.4, 39.0, "broadcast $w^{t+1}$ to all institutions", fontsize=5.4,
        style="italic", color="#c0392b", rotation=90, ha="center",
        va="center", zorder=5)
ax.text(50, 3.4, "Repeat for $T$ communication rounds;  re-cluster every $\\tau$ rounds",
        ha="center", fontsize=6.0, style="italic", color="#444")

os.makedirs("figs", exist_ok=True)
fig.savefig("figs/fig_framework.pdf", bbox_inches="tight")
fig.savefig("figs/fig_framework.png", dpi=600, bbox_inches="tight")
print("wrote figs/fig_framework.pdf")
