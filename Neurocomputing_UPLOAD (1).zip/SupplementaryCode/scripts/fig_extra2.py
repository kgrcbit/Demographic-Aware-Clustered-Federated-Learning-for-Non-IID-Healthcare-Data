"""Two more figures: DP sensitivity curve (real measurement) and a
practitioner decision flowchart tied to the boundary condition."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon
for f in fm.findSystemFonts():
    if "LiberationSerif" in f: fm.fontManager.addfont(f)
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],
 "font.size":9,"axes.labelsize":9,"xtick.labelsize":8,"ytick.labelsize":8,
 "legend.fontsize":7.5,"pdf.fonttype":42,"savefig.dpi":600})
from dcfl.algorithms import distribution_signature, cluster_by_signature
def save(f,n):
    f.savefig(f"figs/{n}.pdf",bbox_inches="tight"); f.savefig(f"figs/{n}.png",dpi=600,bbox_inches="tight")
    plt.close(f); print("wrote",n)

# ---------- DP sensitivity, measured ----------
rng=np.random.default_rng(0); NC=4
clients=[]
for dom,frac in [(0,.80),(0,.75),(1,.72),(3,.69),(1,.55)]:
    n=3000; y=rng.integers(0,NC,size=n); y[rng.random(n)<frac]=dom; clients.append(y)
TRUTH=[0,0,1,1,2]
def agree(l): return sum((l[i]==l[j])==(TRUTH[i]==TRUTH[j]) for i in range(5) for j in range(i+1,5))/10
eps=[0.1,0.5,1.0,5.0,10.0]; sc=[];pc=[];sce=[];pce=[]
for e in eps:
    a=[];b=[]
    for t in range(30):
        s1=[distribution_signature(y,None,None,NC,epsilon=e,sensitivity=1.0,
            rng=np.random.default_rng(1000*t+i)) for i,y in enumerate(clients)]
        s2=[distribution_signature(y,None,None,NC,epsilon=e,
            rng=np.random.default_rng(1000*t+i)) for i,y in enumerate(clients)]
        a.append(agree(cluster_by_signature(np.vstack(s1))))
        b.append(agree(cluster_by_signature(np.vstack(s2))))
    sc.append(np.mean(a)); sce.append(np.std(a)); pc.append(np.mean(b)); pce.append(np.std(b))
fig,ax=plt.subplots(figsize=(3.45,2.4))
ax.errorbar(eps,pc,yerr=pce,marker='o',color='#2ca02c',capsize=2.5,lw=1.4,
            label='per-component $\\Delta s$')
ax.errorbar(eps,sc,yerr=sce,marker='s',color='#d62728',capsize=2.5,lw=1.4,
            ls='--',label='scalar $\\Delta s=1$')
ax.axhline(0.5,color='gray',ls=(0,(3,2)),lw=0.9)
ax.text(9.6,0.52,'chance',fontsize=6.3,ha='right',color='gray')
ax.set_xscale('log'); ax.set_xlabel('Privacy budget $\\epsilon$')
ax.set_ylabel('Cluster recovery (pair agreement)')
ax.set_ylim(0.35,0.92)
ax.set_title('Sensitivity calibration governs whether\nclustering survives privacy noise',fontsize=8.2)
ax.grid(True,lw=0.4,alpha=0.4); ax.set_axisbelow(True)
for sp in("top","right"): ax.spines[sp].set_visible(False)
ax.legend(frameon=False,loc='lower right')
save(fig,"fig_dp")

# ---------- practitioner decision flowchart ----------
fig,ax=plt.subplots(figsize=(3.45,3.6)); ax.set_xlim(0,60); ax.set_ylim(0,100); ax.axis('off')
def bx(x,y,w,h,t,ec,fc,fs=5.8):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0,rounding_size=1.2",
        lw=1.0,edgecolor=ec,facecolor=fc,zorder=2))
    for i,ln in enumerate(t):
        ax.text(x+w/2,y+h-h/(len(t)+0.6)*(i+0.8),ln,ha='center',va='center',fontsize=fs,zorder=3)
def dia(cx,cy,w,h,t,ec,fc,fs=5.6):
    ax.add_patch(Polygon([[cx,cy+h/2],[cx+w/2,cy],[cx,cy-h/2],[cx-w/2,cy]],
        closed=True,lw=1.0,edgecolor=ec,facecolor=fc,zorder=2))
    for i,ln in enumerate(t):
        ax.text(cx,cy+(len(t)-1)*2.0-i*4.0,ln,ha='center',va='center',fontsize=fs,zorder=3)
def ar(x0,y0,x1,y1,txt=None,dx=2.2):
    ax.add_patch(FancyArrowPatch((x0,y0),(x1,y1),arrowstyle='-|>',mutation_scale=9,
        lw=1.0,color='#333',zorder=1))
    if txt: ax.text((x0+x1)/2+dx,(y0+y1)/2,txt,fontsize=5.4,style='italic',color='#333')
bx(12,89,36,8,["Collect class histograms","from each institution"],"#3b6ea5","#eaf1f8")
ar(30,89,30,83)
bx(12,74,36,9,["Form candidate clusters","(signature similarity)"],"#3b6ea5","#eaf1f8")
ar(30,74,30,68)
dia(30,59,44,18,["Does every cluster's","joint label support cover","most of the label space?"],"#c07a1e","#fbeedd")
ar(30,50,30,43,"yes")
bx(10,33,40,10,["Demographic clustering is safe;","expect parity with FedAvg,","not improvement"],"#2c8a52","#e3f3ea")
ar(52,59,56,59); ax.add_patch(FancyArrowPatch((52,59),(56,59),arrowstyle='-',lw=1.0,color='#333'))
ax.add_patch(FancyArrowPatch((56,59),(56,20),arrowstyle='-',lw=1.0,color='#333'))
ax.add_patch(FancyArrowPatch((56,20),(50,20),arrowstyle='-|>',mutation_scale=9,lw=1.0,color='#333'))
ax.text(57.4,40,"no",fontsize=5.4,style='italic',rotation=90,va='center')
bx(10,14,40,12,["Do NOT cluster.","Cluster models will collapse to","constant predictors; use","FedAvg-style aggregation"],"#c0392b","#fdeceb")
ax.text(30,6.5,"The test uses only the class histograms\nalready required to form the clusters.",
        ha='center',fontsize=5.4,style='italic',color='#555')
save(fig,"fig_decision")
