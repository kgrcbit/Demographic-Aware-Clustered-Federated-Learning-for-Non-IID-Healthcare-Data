#!/usr/bin/env python3
"""
Verify every \bibitem in a LaTeX file against Crossref.

    pip install requests
    python verify_refs.py paper_neurocomputing.tex

For each entry it extracts the title, queries Crossref, and reports:
  OK        title matched and the year agrees
  YEAR?     title matched but the year in the paper differs
  VENUE?    title matched but the journal or proceedings name looks different
  NOT FOUND no close title match (arXiv-only and older items often land here,
            which is not automatically an error, but check those by hand)

NOT FOUND does not prove a reference is fake. It means Crossref has no close
match, which happens for arXiv preprints, some workshop papers, and pre-2000
conference items. Check those manually.
"""
import re
import sys
import time

try:
    import requests
except ImportError:
    sys.exit("pip install requests")

API = "https://api.crossref.org/works"
HEADERS = {"User-Agent": "ref-check/1.0 (mailto:you@example.com)"}


def parse_bibitems(path):
    tex = open(path, encoding="utf-8").read()
    body = tex[tex.index(r"\begin{thebibliography}"):]
    chunks = re.split(r"\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}", body)
    out = []
    for i in range(1, len(chunks) - 1, 2):
        key, raw = chunks[i], chunks[i + 1]
        raw = raw.split(r"\end{thebibliography}")[0]
        m = re.search(r"``(.+?),?''", raw, re.S)
        title = m.group(1) if m else None
        if title:
            title = re.sub(r"\\[a-zA-Z]+|[{}~\\]", " ", title)
            title = re.sub(r"\s+", " ", title).strip().rstrip(",.")
        yr = re.findall(r"\b(19|20)\d{2}\b", raw)
        year = re.findall(r"\b((?:19|20)\d{2})\b", raw)
        out.append(dict(key=key, title=title,
                        year=int(year[-1]) if year else None,
                        raw=re.sub(r"\s+", " ", raw).strip()))
    return out


def norm(s):
    return re.sub(r"[^a-z0-9 ]", "", (s or "").lower()).strip()


def check(ref):
    if not ref["title"]:
        return "NO TITLE", ""
    try:
        r = requests.get(API, params={"query.bibliographic": ref["title"],
                                      "rows": 3}, headers=HEADERS, timeout=25)
        r.raise_for_status()
        items = r.json()["message"]["items"]
    except Exception as e:
        return "ERROR", str(e)[:60]

    want = norm(ref["title"])
    for it in items:
        got = norm((it.get("title") or [""])[0])
        if not got:
            continue
        # accept if one title contains the other, or they are very close
        if want[:60] in got or got[:60] in want:
            parts = (it.get("issued", {}).get("date-parts") or [[None]])[0]
            cyear = parts[0] if parts else None
            venue = (it.get("container-title") or [""])[0]
            notes = []
            if ref["year"] and cyear and abs(ref["year"] - cyear) > 1:
                notes.append(f"paper says {ref['year']}, Crossref says {cyear}")
            if venue and norm(venue)[:12] not in norm(ref["raw"]):
                notes.append(f"venue: {venue}")
            if notes:
                return "CHECK", "; ".join(notes)
            return "OK", venue
    return "NOT FOUND", (items[0].get("title", [""])[0][:60] if items else "")


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "paper_neurocomputing.tex"
    refs = parse_bibitems(path)
    print(f"{len(refs)} references found in {path}\n")
    tally = {}
    for i, ref in enumerate(refs, 1):
        status, detail = check(ref)
        tally[status] = tally.get(status, 0) + 1
        flag = " " if status == "OK" else "*"
        print(f"{flag}[{i:2}] {status:9} {ref['key'][:28]:28} {detail[:58]}")
        time.sleep(0.6)   # be polite to the API
    print("\nsummary:", ", ".join(f"{k}={v}" for k, v in sorted(tally.items())))
    print("\nInvestigate every line marked *. NOT FOUND is common for arXiv")
    print("preprints and older conference papers and is not proof of an error.")


if __name__ == "__main__":
    main()
