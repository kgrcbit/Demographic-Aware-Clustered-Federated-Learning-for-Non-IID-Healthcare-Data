# Neurocomputing upload guide (Elsevier Editorial Manager)

Upload each numbered PDF as the matching EM "item type". The manuscript can be
uploaded either as the LaTeX source set or as the single PDF.

| File                              | EM item type                      |
|-----------------------------------|-----------------------------------|
| 01_Cover_Letter.pdf               | Cover Letter                      |
| 02_Highlights.pdf                 | Highlights                        |
| 03_Title_Page.pdf                 | Title Page (with author details)  |
| 04_Declaration_of_Interest.pdf    | Declaration of Interest           |
| 05_CRediT_Author_Statement.pdf    | Author Statement / CRediT         |
| 06_Manuscript.pdf                 | Manuscript (PDF route)            |
| Manuscript/ (tex + Fig1..Fig12)   | Manuscript (LaTeX route)          |
| Figures/Fig1..Fig12               | Figure (one item each, in order)  |
| SupplementaryCode/                | Supplementary Material (optional) |

LaTeX route: upload manuscript.tex plus all twelve Fig*.pdf together. EM
compiles them. Figures are already named in citation order, which Elsevier
requires.

PDF route: upload 06_Manuscript.pdf alone. Simpler, and fine for first
submission. Source will be requested at acceptance.

## Figure order (as cited)
  Fig1  framework architecture       Fig7   label support by dataset
  Fig2  DP sensitivity               Fig8   effect size by class count
  Fig3  convergence S2               Fig9   collapse mechanism
  Fig4  accuracy heatmap             Fig10  disjoint vs overlapping schematic
  Fig5  run-to-run variance          Fig11  per-seed outcomes
  Fig6  fairness across scenarios    Fig12  decision procedure

## During submission you will also be asked for
  - Suggested reviewers (3 to 5, no conflicts, not co-authors)
  - Classification / subject terms
  - Whether the work used generative AI. Answer yes. The disclosure is on the
    title page and in the manuscript Methods section.
  - Open access choice. DECLINE for zero APC. Neurocomputing is hybrid, so the
    subscription route carries no charge.

## STILL TO DO BEFORE YOU CLICK SUBMIT
1. Verify references:
     pip install requests
     python SupplementaryCode/verify_refs.py Manuscript/manuscript.tex
   19 of 51 were checked and two were wrong. The other 32 are unverified.
2. Make the GitHub repository live. The Data Availability statement names it.
3. Add results_derma (50 logs from your Colab/Kaggle run) to the repository and
   regenerate the DermaMNIST row of Table 8 from those logs. It is currently
   the only number in the paper taken from console output rather than a log.
